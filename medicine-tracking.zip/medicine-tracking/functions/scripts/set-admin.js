'use strict';
/**
 * Grants the "admin" custom claim to a user (server-side, trusted).
 *
 * Usage (from the functions/ folder):
 *   node scripts/set-admin.js your-email@gmail.com          # make admin
 *   node scripts/set-admin.js your-email@gmail.com remove   # remove admin
 *
 * Auth: run `gcloud auth application-default login` once, OR set
 * GOOGLE_APPLICATION_CREDENTIALS to a service-account JSON key path.
 * The user must have signed in to the app at least once, then sign out/in
 * again after the claim is set.
 */
const admin = require('firebase-admin');

admin.initializeApp({ projectId: 'medicine-tracking-87531' });

(async () => {
  const email = process.argv[2];
  const remove = process.argv[3] === 'remove';
  if (!email) {
    console.error('Please pass the user email: node scripts/set-admin.js you@gmail.com');
    process.exit(1);
  }
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, remove ? { admin: false } : { admin: true });
  console.log(`${remove ? 'Removed' : 'Granted'} admin for ${email} (uid ${user.uid}). Sign out and in again.`);
  process.exit(0);
})().catch((e) => {
  console.error('Failed:', e.message);
  process.exit(1);
});
