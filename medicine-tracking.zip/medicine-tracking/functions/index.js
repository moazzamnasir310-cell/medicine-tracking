'use strict';

/**
 * Medicine Tracking — Cloud Functions (2nd gen)
 * Secure backend for the AI Health Assistant.
 *
 * Callable functions (Firebase verifies the user's ID token automatically):
 *   sendMessage, deleteConversation, clearConversation, deleteAllConversations,
 *   adminGetOverview, adminUpdateConfig
 *
 * The Gemini API key lives ONLY in Secret Manager (GEMINI_API_KEY).
 */

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { setGlobalOptions } = require('firebase-functions/v2');
const { defineSecret } = require('firebase-functions/params');
const logger = require('firebase-functions/logger');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();
const { FieldValue } = admin.firestore;

setGlobalOptions({ region: 'us-central1', maxInstances: 10 });

const GEMINI_API_KEY = defineSecret('GEMINI_API_KEY');
// Change the model without touching code: set GEMINI_MODEL in functions/.env
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */
const MAX_TEXT = 2000;
const HISTORY_LIMIT = 12;
const HISTORY_CHAR_BUDGET = 12000;
const RATE_PER_MINUTE = 8;
const RATE_PER_DAY = 150;
const GEMINI_TIMEOUT_MS = 45000;
const PROCESSING_LOCK_MS = 90000;
const LANGUAGES = {
  auto: 'the language of the user',
  en: 'English',
  ur: 'Urdu',
  'roman-ur': 'Roman Urdu (Urdu written in Latin letters)',
  hi: 'Hindi',
  ar: 'Arabic',
  pa: 'Punjabi',
};

const DEFAULT_SYSTEM_INSTRUCTION = `You are the AI Health Assistant of Medicine Tracking.

Your purpose is to provide safe, understandable and responsible health education.

You can explain:
- General health questions.
- Medicine information.
- Common medicine uses.
- Common and serious side effects.
- Medicine precautions.
- Possible medicine interactions.
- Basic skin care information.
- General symptom information.
- Healthy lifestyle habits.

Important safety rules:
- Never claim to be a licensed doctor.
- Never provide a definitive diagnosis.
- Never independently prescribe medicine or change a prescribed dose.
- Never invent medicine information.
- Do not claim that unverified information is medically verified.
- Encourage users to consult a qualified healthcare professional for personal treatment decisions.
- Explain emergency warning signs and advise urgent medical help when appropriate.
- Do not recommend stopping prescribed medication without medical advice.
- For possible overdose or severe allergic reactions, advise immediate professional medical assistance.

Language:
- Detect the user's language automatically.
- Reply in the same language.
- Support English, Urdu, Roman Urdu, Hindi, Arabic, Punjabi and other supported languages.
- Respect RTL layout for Urdu and Arabic.

Keep responses clear, helpful and easy to understand.

At the end of relevant health answers, politely ask:
'Would you like any further help with your health?' Translate this naturally into the user's language.`;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
class AiError extends Error {
  constructor(code, userMessage, { status = 0, retryable = false } = {}) {
    super(userMessage);
    this.code = code;
    this.userMessage = userMessage;
    this.status = status;
    this.retryable = retryable;
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function requireAuth(request) {
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError('unauthenticated', 'Please sign in to continue.', { code: 'unauthenticated' });
  }
  return request.auth.uid;
}

function requireAdmin(request) {
  requireAuth(request);
  // Custom claim set only by the server-side script (functions/scripts/set-admin.js)
  if (request.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Administrator access is required.', { code: 'not-admin' });
  }
}

const _cache = new Map();
async function cached(key, ttlMs, loader) {
  const hit = _cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value;
  const value = await loader();
  _cache.set(key, { at: Date.now(), value });
  return value;
}

async function getPublicConfig() {
  return cached('public', 30000, async () => {
    const snap = await db.doc('appConfig/public').get();
    const d = snap.exists ? snap.data() : {};
    return { aiEnabled: d.aiEnabled !== false, announcement: d.announcement || '' };
  });
}

async function getSystemInstruction() {
  return cached('instruction', 60000, async () => {
    const snap = await db.doc('appConfig/private').get();
    const custom = snap.exists ? snap.data().systemInstruction : '';
    return typeof custom === 'string' && custom.trim() ? custom.trim() : DEFAULT_SYSTEM_INSTRUCTION;
  });
}

function validateConversationId(id) {
  if (typeof id !== 'string' || !/^[A-Za-z0-9]{10,40}$/.test(id)) {
    throw new HttpsError('invalid-argument', 'Invalid conversation.', { code: 'bad-conversation' });
  }
}

async function getOwnedConversation(uid, conversationId) {
  validateConversationId(conversationId);
  const ref = db.collection('conversations').doc(conversationId);
  const snap = await ref.get();
  if (!snap.exists) {
    throw new HttpsError('not-found', 'This conversation was not found. It may have been deleted.', { code: 'conversation-not-found' });
  }
  if (snap.data().userId !== uid) {
    throw new HttpsError('permission-denied', 'You do not have access to this conversation.', { code: 'forbidden' });
  }
  return { ref, data: snap.data() };
}

async function consumeRateLimit(uid) {
  const ref = db.doc(`rateLimits/${uid}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const d = snap.exists ? snap.data() : {};
    const now = Date.now();
    const minute = Math.floor(now / 60000);
    const day = Math.floor(now / 86400000);
    const minuteCount = d.minute === minute ? d.minuteCount || 0 : 0;
    const dayCount = d.day === day ? d.dayCount || 0 : 0;
    if (minuteCount >= RATE_PER_MINUTE) {
      throw new HttpsError('resource-exhausted', 'You are sending messages too quickly. Please wait a minute and try again.', { code: 'rate-limit' });
    }
    if (dayCount >= RATE_PER_DAY) {
      throw new HttpsError('resource-exhausted', 'You have reached the daily message limit. Please try again tomorrow.', { code: 'daily-limit' });
    }
    tx.set(ref, { minute, minuteCount: minuteCount + 1, day, dayCount: dayCount + 1, updatedAt: FieldValue.serverTimestamp() });
  });
}

function dayKey(date = new Date()) {
  return date.toISOString().slice(0, 10).replace(/-/g, '');
}

async function recordUsage({ ok, tokens = 0, code = '', status = 0, uid = '' }) {
  try {
    const inc = {
      aiRequests: FieldValue.increment(1),
      aiSuccess: FieldValue.increment(ok ? 1 : 0),
      aiErrors: FieldValue.increment(ok ? 0 : 1),
      totalTokens: FieldValue.increment(tokens || 0),
    };
    const batch = db.batch();
    batch.set(db.doc('stats/global'), inc, { merge: true });
    batch.set(
      db.doc(`stats/daily_${dayKey()}`),
      { date: dayKey(), requests: inc.aiRequests, errors: inc.aiErrors, tokens: inc.totalTokens },
      { merge: true }
    );
    if (!ok) {
      batch.set(db.collection('apiErrors').doc(), {
        code: String(code).slice(0, 40),
        status: Number(status) || 0,
        uid,
        createdAt: FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (e) {
    logger.warn('recordUsage failed', { message: e.message });
  }
}

/* ------------------------------------------------------------------ */
/* Gemini                                                              */
/* ------------------------------------------------------------------ */
function classifyHttpError(status, body) {
  const b = (body || '').toLowerCase();
  if (status === 429) {
    return new AiError('quota', 'The AI service is busy or its quota is used up right now. Please try again later.', { status, retryable: false });
  }
  if (status === 401 || status === 403 || (status === 400 && (b.includes('api key') || b.includes('api_key')))) {
    return new AiError('invalid-key', 'The AI service is not configured correctly. Please contact the app administrator.', { status });
  }
  if (status === 404) {
    return new AiError('invalid-model', 'The AI model is not available. Please contact the app administrator.', { status });
  }
  if (status === 408 || status === 504) {
    return new AiError('timeout', 'The AI took too long to answer. Please try again.', { status, retryable: true });
  }
  if (status >= 500) {
    return new AiError('unavailable', 'The AI service is temporarily unavailable. Please try again in a moment.', { status, retryable: true });
  }
  return new AiError('ai-error', 'The AI could not process this request. Please rephrase and try again.', { status });
}

async function callGemini({ apiKey, systemInstruction, contents }) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`;
  const generationConfig = { temperature: 0.4, topP: 0.9, maxOutputTokens: 2048 };
  if (/flash/i.test(GEMINI_MODEL) && /2\.5/.test(GEMINI_MODEL)) {
    generationConfig.thinkingConfig = { thinkingBudget: 0 };
  }
  const payload = JSON.stringify({
    systemInstruction: { parts: [{ text: systemInstruction }] },
    contents,
    generationConfig,
  });

  let lastError;
  for (let attempt = 0; attempt < 2; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), GEMINI_TIMEOUT_MS);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
        body: payload,
        signal: ctrl.signal,
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        logger.warn('Gemini HTTP error', { status: res.status, body: body.slice(0, 300) });
        throw classifyHttpError(res.status, body);
      }
      const data = await res.json();
      if (data.promptFeedback && data.promptFeedback.blockReason) {
        throw new AiError('blocked', 'I could not answer that request. Please rephrase your question.');
      }
      const cand = data.candidates && data.candidates[0];
      const parts = (cand && cand.content && cand.content.parts) || [];
      const text = parts.map((p) => p.text || '').join('').trim();
      if (!text) {
        if (cand && cand.finishReason === 'SAFETY') {
          throw new AiError('blocked', 'I could not answer that request. Please rephrase your question.');
        }
        throw new AiError('empty', 'The AI returned an empty answer. Please try again.', { retryable: true });
      }
      const tokens = (data.usageMetadata && data.usageMetadata.totalTokenCount) || 0;
      return { text, tokens };
    } catch (e) {
      lastError = e;
      if (e.name === 'AbortError') {
        lastError = new AiError('timeout', 'The AI took too long to answer. Please try again.', { status: 408, retryable: true });
      } else if (!(e instanceof AiError)) {
        lastError = new AiError('unavailable', 'The AI service could not be reached. Please try again.', { retryable: true });
      }
      if (lastError.retryable && attempt === 0) {
        await sleep(900);
        continue;
      }
      throw lastError;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError;
}

async function loadHistory(convRef) {
  const snap = await convRef.collection('messages').orderBy('timestamp', 'desc').limit(HISTORY_LIMIT).get();
  const items = [];
  let budget = HISTORY_CHAR_BUDGET;
  for (const doc of snap.docs) {
    const d = doc.data();
    if (!d.text || (d.sender === 'user' && d.status === 'failed')) continue;
    const text = String(d.text).slice(0, MAX_TEXT * 2);
    budget -= text.length;
    if (budget < 0 && items.length > 0) break;
    items.push({ role: d.sender === 'assistant' ? 'model' : 'user', text });
  }
  items.reverse();
  // Merge consecutive same-role turns and make sure we start with a user turn.
  const contents = [];
  for (const it of items) {
    const last = contents[contents.length - 1];
    if (last && last.role === it.role) last.parts[0].text += '\n\n' + it.text;
    else contents.push({ role: it.role, parts: [{ text: it.text }] });
  }
  while (contents.length && contents[0].role !== 'user') contents.shift();
  return contents;
}

const preview = (s, n = 120) => {
  const t = String(s).replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n - 1) + '…' : t;
};

const AI_HTTPS_CODE = {
  quota: 'resource-exhausted',
  timeout: 'deadline-exceeded',
  unavailable: 'unavailable',
  'invalid-key': 'failed-precondition',
  'invalid-model': 'failed-precondition',
  blocked: 'failed-precondition',
};

/* ------------------------------------------------------------------ */
/* sendMessage                                                         */
/* ------------------------------------------------------------------ */
exports.sendMessage = onCall(
  { secrets: [GEMINI_API_KEY], timeoutSeconds: 120, memory: '256MiB' },
  async (request) => {
    const uid = requireAuth(request);
    const { conversationId, clientMessageId, text, language, preferredLanguage } = request.data || {};

    if (typeof text !== 'string' || !text.trim()) {
      throw new HttpsError('invalid-argument', 'Please type a message first.', { code: 'empty-message' });
    }
    if (text.trim().length > MAX_TEXT) {
      throw new HttpsError('invalid-argument', `Your message is too long. Please keep it under ${MAX_TEXT} characters.`, { code: 'too-long' });
    }
    if (typeof clientMessageId !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(clientMessageId)) {
      throw new HttpsError('invalid-argument', 'Invalid request.', { code: 'bad-id' });
    }
    const lang = Object.prototype.hasOwnProperty.call(LANGUAGES, language) ? language : 'auto';
    const pref = Object.prototype.hasOwnProperty.call(LANGUAGES, preferredLanguage) ? preferredLanguage : 'auto';
    const cleanText = text.trim();

    const config = await getPublicConfig();
    if (!config.aiEnabled) {
      throw new HttpsError('failed-precondition', 'AI chat is temporarily disabled by the administrator.', { code: 'ai-disabled' });
    }

    const { ref: convRef } = await getOwnedConversation(uid, conversationId);
    const userRef = convRef.collection('messages').doc(clientMessageId);
    const aiRef = convRef.collection('messages').doc(`${clientMessageId}_ai`);

    // Already answered (duplicate click / retry after success) -> do nothing.
    if ((await aiRef.get()).exists) return { ok: true, duplicate: true, messageId: aiRef.id };

    await consumeRateLimit(uid);

    // Idempotent claim of this message (prevents duplicate AI calls).
    let userText = cleanText;
    const state = await db.runTransaction(async (tx) => {
      const [u, a] = await Promise.all([tx.get(userRef), tx.get(aiRef)]);
      if (a.exists) return 'done';
      if (u.exists) {
        const d = u.data();
        if (d.sender !== 'user') return 'conflict';
        if (d.status === 'processing' && Date.now() - (d.processingAtMs || 0) < PROCESSING_LOCK_MS) return 'busy';
        userText = d.text;
        tx.update(userRef, { status: 'processing', processingAtMs: Date.now(), errorCode: FieldValue.delete() });
      } else {
        tx.create(userRef, {
          sender: 'user',
          text: cleanText,
          timestamp: FieldValue.serverTimestamp(),
          status: 'processing',
          processingAtMs: Date.now(),
          language: lang,
        });
      }
      return 'go';
    });
    if (state === 'done') return { ok: true, duplicate: true, messageId: aiRef.id };
    if (state === 'conflict') throw new HttpsError('invalid-argument', 'Invalid request.', { code: 'bad-id' });
    if (state === 'busy') {
      throw new HttpsError('already-exists', 'Your previous message is still being answered. Please wait a moment.', { code: 'busy' });
    }

    try {
      const [baseInstruction, history] = await Promise.all([getSystemInstruction(), loadHistory(convRef)]);
      const langName = LANGUAGES[pref];
      const systemInstruction =
        `${baseInstruction}\n\n` +
        (pref === 'auto'
          ? 'Reply in the same language and script as the user\'s latest message.'
          : `Reply in the language and script of the user's latest message. If it is unclear, use ${langName}.`) +
        '\nFormatting: use short paragraphs and simple bullet lists. Do not use tables or code blocks.';

      let contents = history;
      if (!contents.length || contents[contents.length - 1].role !== 'user') {
        contents = [...contents, { role: 'user', parts: [{ text: userText }] }];
      }

      const { text: answer, tokens } = await callGemini({
        apiKey: GEMINI_API_KEY.value(),
        systemInstruction,
        contents,
      });

      const batch = db.batch();
      batch.create(aiRef, {
        sender: 'assistant',
        text: answer,
        timestamp: FieldValue.serverTimestamp(),
        status: 'sent',
        language: lang,
        model: GEMINI_MODEL,
      });
      batch.update(userRef, { status: 'sent', errorCode: FieldValue.delete(), processingAtMs: FieldValue.delete() });
      batch.update(convRef, { lastMessage: preview(answer), updatedAt: FieldValue.serverTimestamp() });
      await batch.commit();

      await recordUsage({ ok: true, tokens });
      return { ok: true, messageId: aiRef.id };
    } catch (e) {
      const code = e instanceof AiError ? e.code : 'internal';
      await userRef
        .update({ status: 'failed', errorCode: code, processingAtMs: FieldValue.delete() })
        .catch(() => {});
      await recordUsage({ ok: false, code, status: e.status, uid });
      logger.error('sendMessage failed', { code, status: e.status, message: e.message });
      if (e instanceof AiError) {
        throw new HttpsError(AI_HTTPS_CODE[e.code] || 'internal', e.userMessage, { code: e.code });
      }
      throw new HttpsError('internal', 'Something went wrong on our side. Please try again.', { code: 'internal' });
    }
  }
);

/* ------------------------------------------------------------------ */
/* Conversation deletion                                               */
/* ------------------------------------------------------------------ */
exports.deleteConversation = onCall({ timeoutSeconds: 120 }, async (request) => {
  const uid = requireAuth(request);
  const { ref } = await getOwnedConversation(uid, (request.data || {}).conversationId);
  await db.recursiveDelete(ref);
  return { ok: true };
});

exports.clearConversation = onCall({ timeoutSeconds: 120 }, async (request) => {
  const uid = requireAuth(request);
  const { ref } = await getOwnedConversation(uid, (request.data || {}).conversationId);
  await db.recursiveDelete(ref.collection('messages'));
  await ref.update({ lastMessage: '', updatedAt: FieldValue.serverTimestamp() });
  return { ok: true };
});

exports.deleteAllConversations = onCall({ timeoutSeconds: 300 }, async (request) => {
  const uid = requireAuth(request);
  let deleted = 0;
  for (let i = 0; i < 40; i++) {
    const snap = await db.collection('conversations').where('userId', '==', uid).limit(25).get();
    if (snap.empty) break;
    for (const doc of snap.docs) {
      await db.recursiveDelete(doc.ref);
      deleted++;
    }
  }
  return { ok: true, deleted };
});

/* ------------------------------------------------------------------ */
/* Admin                                                               */
/* ------------------------------------------------------------------ */
exports.adminGetOverview = onCall({ timeoutSeconds: 60 }, async (request) => {
  requireAdmin(request);

  const days = [];
  for (let i = 6; i >= 0; i--) days.push(dayKey(new Date(Date.now() - i * 86400000)));

  const [users, convs, msgs, globalSnap, dailySnaps, errSnap, pub, priv] = await Promise.all([
    db.collection('users').count().get(),
    db.collection('conversations').count().get(),
    db.collectionGroup('messages').count().get(),
    db.doc('stats/global').get(),
    Promise.all(days.map((d) => db.doc(`stats/daily_${d}`).get())),
    db.collection('apiErrors').orderBy('createdAt', 'desc').limit(20).get(),
    db.doc('appConfig/public').get(),
    db.doc('appConfig/private').get(),
  ]);

  const g = globalSnap.exists ? globalSnap.data() : {};
  const pubData = pub.exists ? pub.data() : {};
  const custom = priv.exists ? priv.data().systemInstruction : '';

  return {
    counts: {
      users: users.data().count,
      conversations: convs.data().count,
      messages: msgs.data().count,
    },
    ai: {
      requests: g.aiRequests || 0,
      success: g.aiSuccess || 0,
      errors: g.aiErrors || 0,
      tokens: g.totalTokens || 0,
      model: GEMINI_MODEL,
    },
    daily: days.map((d, i) => {
      const s = dailySnaps[i].exists ? dailySnaps[i].data() : {};
      return { date: d, requests: s.requests || 0, errors: s.errors || 0, tokens: s.tokens || 0 };
    }),
    errors: errSnap.docs.map((d) => {
      const e = d.data();
      return { code: e.code, status: e.status, createdAt: e.createdAt ? e.createdAt.toMillis() : 0 };
    }),
    config: {
      aiEnabled: pubData.aiEnabled !== false,
      announcement: pubData.announcement || '',
      systemInstruction: typeof custom === 'string' && custom.trim() ? custom : '',
      usingDefaultInstruction: !(typeof custom === 'string' && custom.trim()),
    },
    defaultInstruction: DEFAULT_SYSTEM_INSTRUCTION,
  };
});

exports.adminUpdateConfig = onCall({ timeoutSeconds: 30 }, async (request) => {
  requireAdmin(request);
  const data = request.data || {};
  const pub = {};
  const priv = {};

  if ('aiEnabled' in data) {
    if (typeof data.aiEnabled !== 'boolean') throw new HttpsError('invalid-argument', 'Invalid value.');
    pub.aiEnabled = data.aiEnabled;
  }
  if ('announcement' in data) {
    if (typeof data.announcement !== 'string' || data.announcement.length > 500) {
      throw new HttpsError('invalid-argument', 'Announcement must be text up to 500 characters.');
    }
    pub.announcement = data.announcement.trim();
    pub.announcementUpdatedAt = Date.now();
  }
  if ('systemInstruction' in data) {
    if (typeof data.systemInstruction !== 'string' || data.systemInstruction.length > 8000) {
      throw new HttpsError('invalid-argument', 'Instruction must be text up to 8000 characters.');
    }
    priv.systemInstruction = data.systemInstruction.trim() ? data.systemInstruction.trim() : FieldValue.delete();
  }

  const writes = [];
  if (Object.keys(pub).length) {
    writes.push(db.doc('appConfig/public').set({ ...pub, updatedAt: FieldValue.serverTimestamp() }, { merge: true }));
  }
  if (Object.keys(priv).length) {
    writes.push(db.doc('appConfig/private').set({ ...priv, updatedAt: FieldValue.serverTimestamp() }, { merge: true }));
  }
  await Promise.all(writes);
  _cache.clear();
  return { ok: true };
});
