// Caches the static app shell so the UI opens fast and works offline.
// Firebase / Firestore / Functions / Auth traffic is NEVER cached or intercepted.
const CACHE = 'medicine-tracking-shell-v1';
const SHELL = [
  './',
  'index.html',
  'manifest.json',
  'icons/icon.svg',
  'css/style.css',
  'css/chat.css',
  'css/animations.css',
  'css/responsive.css',
  'js/app.js',
  'js/auth.js',
  'js/chat.js',
  'js/conversation.js',
  'js/voice.js',
  'js/language.js',
  'js/utils.js',
  'js/admin.js',
  'js/firebase-config.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // Only handle our own files. Skip Firebase Auth helper pages (/__/...) and all other origins.
  if (url.origin !== self.location.origin || url.pathname.startsWith('/__/')) return;

  // Pages: network first, fall back to cached shell when offline.
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).catch(() => caches.match('index.html')));
    return;
  }

  // Static assets: stale-while-revalidate.
  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req)
        .then((res) => {
          if (res && res.ok) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
