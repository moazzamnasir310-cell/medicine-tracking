// Shared helpers: DOM, icons, markdown, dialogs, toasts, error messages.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/* ---------------------------- Icons ---------------------------- */
const ICONS = {
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  volume: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  retry: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  mic: '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>',
  send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  menu: '<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  sun: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  alert: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  globe: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  clear: '<circle cx="12" cy="12" r="10"/><line x1="8" y1="12" x2="16" y2="12"/>',
  chevronDown: '<polyline points="6 9 12 15 18 9"/>',
  activity: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
  pill: '<path d="M10.5 20.5a5 5 0 0 1-7-7l10-10a5 5 0 0 1 7 7z"/><line x1="8.5" y1="8.5" x2="15.5" y2="15.5"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
};

export function icon(name, size = 18) {
  return `<svg class="ic" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

/** Fill every <span data-icon="name"> placeholder in the document. */
export function hydrateIcons(root = document) {
  $$('[data-icon]', root).forEach((el) => {
    el.innerHTML = icon(el.dataset.icon, Number(el.dataset.size) || 18);
    el.removeAttribute('data-icon');
  });
}

export const LOGO_SVG = `<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0b6fd6"/><stop offset="1" stop-color="#2aa5ff"/></linearGradient></defs><rect width="48" height="48" rx="13" fill="url(#lg)"/><path d="M20 11h8v9h9v8h-9v9h-8v-9h-9v-8h9z" fill="#fff"/></svg>`;

/* --------------------------- Text utils --------------------------- */
export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Tiny, safe markdown renderer (escape first, then format). */
export function renderMarkdown(src) {
  const lines = String(src).replace(/\r\n/g, '\n').split('\n');
  let html = '';
  let list = null;
  const closeList = () => {
    if (list) {
      html += `</${list}>`;
      list = null;
    }
  };
  const inline = (s) =>
    escapeHtml(s)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>');
  for (const raw of lines) {
    const line = raw.trimEnd();
    let m;
    if (!line.trim()) {
      closeList();
    } else if ((m = line.match(/^\s*#{1,4}\s+(.*)$/))) {
      closeList();
      html += `<h4>${inline(m[1])}</h4>`;
    } else if ((m = line.match(/^\s*[-*•]\s+(.*)$/))) {
      if (list !== 'ul') {
        closeList();
        html += '<ul>';
        list = 'ul';
      }
      html += `<li>${inline(m[1])}</li>`;
    } else if ((m = line.match(/^\s*(\d+)[.)]\s+(.*)$/))) {
      if (list !== 'ol') {
        closeList();
        html += '<ol>';
        list = 'ol';
      }
      html += `<li>${inline(m[2])}</li>`;
    } else {
      closeList();
      html += `<p>${inline(line)}</p>`;
    }
  }
  closeList();
  return html;
}

export function plainText(md) {
  return String(md).replace(/[*_`#]/g, '').replace(/^\s*[-•]\s+/gm, '').trim();
}

/* ------------------------------ Time ------------------------------ */
export function formatTime(ms, locale) {
  try {
    return new Intl.DateTimeFormat(locale || undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(ms));
  } catch {
    return '';
  }
}

export function formatDay(ms, locale) {
  const d = new Date(ms);
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  const same = (a, b) => a.toDateString() === b.toDateString();
  if (same(d, today)) return 'Today';
  if (same(d, y)) return 'Yesterday';
  try {
    return new Intl.DateTimeFormat(locale || undefined, { day: 'numeric', month: 'short', year: 'numeric' }).format(d);
  } catch {
    return d.toDateString();
  }
}

export const newId = () => {
  if (crypto && crypto.randomUUID) return crypto.randomUUID().replace(/-/g, '');
  return Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
};

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand('copy');
    } catch {
      ok = false;
    }
    ta.remove();
    return ok;
  }
}

/* ----------------------------- Toasts ----------------------------- */
export function toast(message, type = 'info', ms = 4500) {
  let root = $('#toast-root');
  if (!root) {
    root = document.createElement('div');
    root.id = 'toast-root';
    root.setAttribute('aria-live', 'polite');
    document.body.appendChild(root);
  }
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.setAttribute('role', type === 'error' ? 'alert' : 'status');
  el.innerHTML = `${icon(type === 'error' ? 'alert' : type === 'success' ? 'check' : 'info', 18)}<span></span>`;
  el.querySelector('span').textContent = message;
  root.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, ms);
}

/* ----------------------------- Dialogs ----------------------------- */
function openModal(build) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    overlay.appendChild(modal);
    const previous = document.activeElement;
    const close = (value) => {
      document.removeEventListener('keydown', onKey, true);
      overlay.classList.remove('show');
      setTimeout(() => overlay.remove(), 180);
      if (previous && previous.focus) previous.focus();
      resolve(value);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        close(null);
      }
    };
    document.addEventListener('keydown', onKey, true);
    overlay.addEventListener('mousedown', (e) => {
      if (e.target === overlay) close(null);
    });
    build(modal, close);
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('show'));
  });
}

export function confirmDialog({ title, message, confirmText = 'Confirm', cancelText = 'Cancel', danger = false }) {
  return openModal((modal, close) => {
    modal.innerHTML = `<h3></h3><p></p><div class="modal-actions"><button type="button" class="btn btn-ghost" data-a="no"></button><button type="button" class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-a="yes"></button></div>`;
    modal.querySelector('h3').textContent = title;
    modal.querySelector('p').textContent = message;
    modal.querySelector('[data-a=no]').textContent = cancelText;
    const yes = modal.querySelector('[data-a=yes]');
    yes.textContent = confirmText;
    modal.querySelector('[data-a=no]').onclick = () => close(false);
    yes.onclick = () => close(true);
    setTimeout(() => modal.querySelector('[data-a=no]').focus(), 30);
  }).then((v) => v === true);
}

export function promptDialog({ title, label, value = '', confirmText = 'Save', cancelText = 'Cancel', maxLength = 80 }) {
  return openModal((modal, close) => {
    modal.innerHTML = `<h3></h3><form><label class="field-label"></label><input class="input" type="text" required /><div class="modal-actions"><button type="button" class="btn btn-ghost" data-a="no"></button><button type="submit" class="btn btn-primary"></button></div></form>`;
    modal.querySelector('h3').textContent = title;
    modal.querySelector('label').textContent = label;
    const input = modal.querySelector('input');
    input.value = value;
    input.maxLength = maxLength;
    modal.querySelector('[data-a=no]').textContent = cancelText;
    modal.querySelector('[type=submit]').textContent = confirmText;
    modal.querySelector('[data-a=no]').onclick = () => close(null);
    modal.querySelector('form').onsubmit = (e) => {
      e.preventDefault();
      const v = input.value.trim();
      if (v) close(v);
    };
    setTimeout(() => {
      input.focus();
      input.select();
    }, 30);
  });
}

/* ------------------------- Friendly errors ------------------------- */
const CODE_MESSAGES = {
  quota: 'The AI service is busy or its quota is used up right now. Please try again later.',
  'invalid-key': 'The AI service is not configured correctly. Please contact the app administrator.',
  'invalid-model': 'The AI model is not available. Please contact the app administrator.',
  timeout: 'The AI took too long to answer. Please try again.',
  unavailable: 'The AI service is temporarily unavailable. Please try again in a moment.',
  blocked: 'I could not answer that request. Please rephrase your question.',
  empty: 'The AI returned an empty answer. Please try again.',
  internal: 'Something went wrong on our side. Please try again.',
  'ai-error': 'The AI could not process this request. Please rephrase and try again.',
};

export function codeMessage(code) {
  return CODE_MESSAGES[code] || 'The message could not be answered. Please try again.';
}

const AUTH_MESSAGES = {
  'auth/popup-closed-by-user': '',
  'auth/cancelled-popup-request': '',
  'auth/popup-blocked': 'Your browser blocked the sign-in window. Allow pop-ups and try again.',
  'auth/network-request-failed': 'No internet connection. Please check your network and try again.',
  'auth/unauthorized-domain': 'This website address is not authorised for sign-in. Add it in Firebase Console → Authentication → Settings → Authorized domains.',
  'auth/operation-not-allowed': 'Google sign-in is not enabled. Enable it in Firebase Console → Authentication → Sign-in method.',
  'auth/user-disabled': 'This account has been disabled.',
  'auth/too-many-requests': 'Too many attempts. Please wait a moment and try again.',
};

export function friendlyError(err) {
  if (!navigator.onLine) return 'You are offline. Please reconnect to the internet and try again.';
  const code = (err && err.code) || '';
  if (code.startsWith('auth/')) {
    return code in AUTH_MESSAGES ? AUTH_MESSAGES[code] : 'Sign-in failed. Please try again.';
  }
  const backendCode = err && err.details && err.details.code;
  if (code.startsWith('functions/')) {
    if (code === 'functions/unauthenticated') return 'Your session has expired. Please sign in again.';
    if (code === 'functions/internal' && !err.message) return CODE_MESSAGES.internal;
    if (backendCode && CODE_MESSAGES[backendCode]) return CODE_MESSAGES[backendCode];
    if (code === 'functions/unavailable') return 'The service is not reachable right now. Please check your connection and try again.';
    if (code === 'functions/not-found' && !backendCode) {
      return 'The chat service is not deployed yet. Deploy the Cloud Functions first (see README).';
    }
    if (err.message && err.message.toLowerCase() !== 'internal') return err.message;
    return CODE_MESSAGES.internal;
  }
  if (code === 'permission-denied') return 'You do not have permission to do that.';
  if (code === 'unavailable') return 'Cannot reach the server. Your changes will sync when you are back online.';
  if (code === 'failed-precondition') return 'A database index is still building or missing. Deploy firestore.indexes.json and try again shortly.';
  if (code === 'resource-exhausted') return 'The free daily database quota may be used up. Try again later.';
  if (code === 'unauthenticated') return 'Please sign in to continue.';
  return 'Something went wrong. Please try again.';
}

export const debounce = (fn, ms = 200) => {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
};
