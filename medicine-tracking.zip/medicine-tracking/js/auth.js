// Firebase Authentication (Google) + Firestore user profile.
import {
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  onAuthStateChanged,
  signOut,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { auth, db } from './firebase-config.js';
import { friendlyError } from './utils.js';
import { VALID_CODES } from './language.js';

const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: 'select_account' });

/** Create the profile on first login, or refresh it for returning users. */
async function ensureUserProfile(user) {
  const ref = doc(db, 'users', user.uid);
  const snap = await getDoc(ref);
  const base = {
    displayName: user.displayName || '',
    email: user.email || '',
    photoURL: user.photoURL || '',
  };
  if (!snap.exists()) {
    const profile = {
      uid: user.uid,
      ...base,
      preferredLanguage: 'auto',
      createdAt: serverTimestamp(),
      lastLoginAt: serverTimestamp(),
    };
    await setDoc(ref, profile);
    return { uid: user.uid, ...base, preferredLanguage: 'auto' };
  }
  const data = snap.data();
  await updateDoc(ref, { ...base, lastLoginAt: serverTimestamp() });
  const pref = VALID_CODES.includes(data.preferredLanguage) ? data.preferredLanguage : 'auto';
  return { ...data, ...base, preferredLanguage: pref };
}

/**
 * Subscribe to auth state. The callback receives
 * { user, profile, isAdmin } when signed in, or null when signed out.
 * Admin status comes from the server-set custom claim (never from the browser).
 */
export function watchAuth(callback) {
  getRedirectResult(auth).catch((e) => callback(null, friendlyError(e)));
  return onAuthStateChanged(auth, async (user) => {
    if (!user) {
      callback(null);
      return;
    }
    try {
      const [profile, token] = await Promise.all([ensureUserProfile(user), user.getIdTokenResult(true)]);
      callback({ user, profile, isAdmin: token.claims.admin === true });
    } catch (e) {
      console.error('Profile load failed', e);
      callback(null, friendlyError(e));
      signOut(auth).catch(() => {});
    }
  });
}

export async function signInWithGoogle() {
  try {
    await signInWithPopup(auth, provider);
    return '';
  } catch (e) {
    if (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment') {
      await signInWithRedirect(auth, provider);
      return '';
    }
    return friendlyError(e);
  }
}

export const logout = () => signOut(auth);

export async function savePreferredLanguage(uid, code) {
  if (!VALID_CODES.includes(code)) return;
  await updateDoc(doc(db, 'users', uid), { preferredLanguage: code });
}
