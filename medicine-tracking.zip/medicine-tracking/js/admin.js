// Admin panel. Every action goes through Cloud Functions that verify the
// `admin` custom claim on the server — hiding this screen is only cosmetic.
import { httpsCallable } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js';
import { functions } from './firebase-config.js';
import { $, icon, toast, friendlyError, confirmDialog, formatTime } from './utils.js';

const getOverview = httpsCallable(functions, 'adminGetOverview');
const updateConfig = httpsCallable(functions, 'adminUpdateConfig');

let data = null;

const fmt = (n) => new Intl.NumberFormat().format(n || 0);

export async function openAdmin() {
  const view = $('#admin-view');
  view.hidden = false;
  document.body.classList.add('admin-open');
  await refresh();
}

export function closeAdmin() {
  $('#admin-view').hidden = true;
  document.body.classList.remove('admin-open');
}

async function refresh() {
  const body = $('#admin-body');
  body.innerHTML = '<div class="admin-loading"><span class="spinner"></span> Loading…</div>';
  try {
    const res = await getOverview();
    data = res.data;
    render();
  } catch (e) {
    body.innerHTML = '';
    const p = document.createElement('p');
    p.className = 'form-error';
    p.textContent = friendlyError(e);
    body.appendChild(p);
  }
}

function render() {
  const { counts, ai, daily, errors, config } = data;
  const maxReq = Math.max(1, ...daily.map((d) => d.requests));
  const body = $('#admin-body');
  body.innerHTML = `
    <section class="stat-grid">
      ${stat('Registered users', counts.users)}
      ${stat('Conversations', counts.conversations)}
      ${stat('Messages', counts.messages)}
      ${stat('AI requests', ai.requests)}
      ${stat('AI successes', ai.success)}
      ${stat('API errors', ai.errors, ai.errors ? 'warn' : '')}
      ${stat('Tokens used', ai.tokens)}
    </section>

    <section class="card">
      <div class="card-head"><h3>${icon('activity', 18)} Last 7 days</h3><span class="muted">Model: <b>${ai.model}</b></span></div>
      <div class="bars" role="img" aria-label="AI requests per day">
        ${daily
          .map(
            (d) => `<div class="bar-col"><div class="bar-val">${fmt(d.requests)}</div>
              <div class="bar" style="height:${Math.max(4, (d.requests / maxReq) * 100)}%"><i style="height:${d.requests ? Math.min(100, (d.errors / d.requests) * 100) : 0}%"></i></div>
              <div class="bar-label">${d.date.slice(4, 6)}/${d.date.slice(6, 8)}</div></div>`
          )
          .join('')}
      </div>
      <p class="muted small">Dark segment at the bottom of each bar = failed requests.</p>
    </section>

    <section class="card">
      <div class="card-head"><h3>AI chat status</h3></div>
      <label class="switch-row big">
        <span><b id="ai-state-label">${config.aiEnabled ? 'AI chat is ON' : 'AI chat is OFF'}</b><br><span class="muted small">When off, users see a notice and cannot send messages.</span></span>
        <input type="checkbox" class="switch" id="ai-toggle" ${config.aiEnabled ? 'checked' : ''} />
      </label>
    </section>

    <section class="card">
      <div class="card-head"><h3>Announcement</h3></div>
      <p class="muted small">Shown to every signed-in user at the top of the chat. Leave empty to hide.</p>
      <textarea id="announce-input" class="input" rows="3" maxlength="500" placeholder="e.g. Scheduled maintenance tonight at 10 PM."></textarea>
      <div class="row-end"><button class="btn btn-primary" id="announce-save">Save announcement</button></div>
    </section>

    <section class="card">
      <div class="card-head"><h3>AI system instruction</h3><span class="chip">${config.usingDefaultInstruction ? 'Using default' : 'Custom'}</span></div>
      <p class="muted small">Controls how the AI Health Assistant behaves. Keep the safety rules. Max 8000 characters.</p>
      <textarea id="instruction-input" class="input mono" rows="14" maxlength="8000"></textarea>
      <div class="row-end">
        <button class="btn btn-ghost" id="instruction-reset">Reset to default</button>
        <button class="btn btn-primary" id="instruction-save">Save instruction</button>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h3>${icon('alert', 18)} Recent API errors</h3></div>
      ${
        errors.length
          ? `<div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>Code</th><th>HTTP</th></tr></thead><tbody>${errors
              .map(
                (e) =>
                  `<tr><td>${e.createdAt ? new Date(e.createdAt).toLocaleDateString() + ' ' + formatTime(e.createdAt) : '—'}</td><td><code>${e.code || '—'}</code></td><td>${e.status || '—'}</td></tr>`
              )
              .join('')}</tbody></table></div>`
          : '<p class="muted">No errors recorded. 🎉</p>'
      }
    </section>`;

  $('#announce-input').value = config.announcement;
  $('#instruction-input').value = config.systemInstruction || data.defaultInstruction;

  $('#ai-toggle').onchange = async (e) => {
    const enabled = e.target.checked;
    e.target.disabled = true;
    try {
      await updateConfig({ aiEnabled: enabled });
      $('#ai-state-label').textContent = enabled ? 'AI chat is ON' : 'AI chat is OFF';
      toast(enabled ? 'AI chat enabled' : 'AI chat disabled', 'success');
    } catch (err) {
      e.target.checked = !enabled;
      toast(friendlyError(err), 'error');
    } finally {
      e.target.disabled = false;
    }
  };

  $('#announce-save').onclick = () => save({ announcement: $('#announce-input').value }, 'Announcement saved');

  $('#instruction-save').onclick = async () => {
    const value = $('#instruction-input').value;
    if (value.trim().length < 50) {
      toast('Instruction is too short. Use "Reset to default" to restore the default.', 'error');
      return;
    }
    // Saving identical-to-default text keeps the "default" state.
    await save({ systemInstruction: value.trim() === data.defaultInstruction.trim() ? '' : value }, 'Instruction saved (applies within a minute)');
  };

  $('#instruction-reset').onclick = async () => {
    const ok = await confirmDialog({
      title: 'Reset instruction?',
      message: 'This restores the built-in safe default instruction.',
      confirmText: 'Reset',
    });
    if (ok) await save({ systemInstruction: '' }, 'Default instruction restored');
  };
}

async function save(payload, okMessage) {
  try {
    await updateConfig(payload);
    toast(okMessage, 'success');
    await refresh();
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

function stat(label, value, tone = '') {
  return `<div class="stat ${tone}"><div class="stat-value">${fmt(value)}</div><div class="stat-label">${label}</div></div>`;
}

export function initAdmin() {
  $('#admin-back').addEventListener('click', closeAdmin);
  $('#admin-refresh').addEventListener('click', refresh);
}
