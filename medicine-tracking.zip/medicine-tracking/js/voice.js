// Voice: speech-to-text (microphone) and text-to-speech (read aloud).
// Nothing is recorded or sent anywhere by this app: recognition is started only
// by an explicit click and stops after one phrase or when the user stops it.
import { plainText } from './utils.js';

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

export const voiceSupport = {
  recognition: !!SR,
  synthesis: 'speechSynthesis' in window,
};

/* ------------------------- Speech to text ------------------------- */
export class VoiceInput {
  constructor({ onText, onStart, onEnd, onError }) {
    this.onText = onText;
    this.onStart = onStart;
    this.onEnd = onEnd;
    this.onError = onError;
    this.rec = null;
    this.active = false;
  }

  async start(lang) {
    if (!SR) {
      this.onError?.('unsupported');
      return;
    }
    if (this.active) return;

    // Ask for microphone permission explicitly, then release the mic immediately.
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
      } catch (e) {
        this.onError?.(e && e.name === 'NotFoundError' ? 'no-mic' : 'not-allowed');
        return;
      }
    }

    const rec = new SR();
    rec.lang = lang || navigator.language || 'en-US';
    rec.continuous = false;
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    let finalText = '';
    rec.onstart = () => {
      this.active = true;
      this.onStart?.();
    };
    rec.onresult = (ev) => {
      let interim = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const r = ev.results[i];
        if (r.isFinal) finalText += r[0].transcript;
        else interim += r[0].transcript;
      }
      this.onText?.((finalText + interim).trim(), !interim);
    };
    rec.onerror = (ev) => {
      if (ev.error !== 'aborted' && ev.error !== 'no-speech') this.onError?.(ev.error);
      if (ev.error === 'no-speech') this.onError?.('no-speech');
    };
    rec.onend = () => {
      this.active = false;
      this.rec = null;
      this.onEnd?.();
    };
    this.rec = rec;
    try {
      rec.start();
    } catch {
      this.active = false;
      this.onError?.('start-failed');
    }
  }

  stop() {
    if (this.rec) {
      try {
        this.rec.stop();
      } catch {
        /* ignore */
      }
    }
  }
}

/* ------------------------- Text to speech ------------------------- */
let speaking = false;
let listeners = [];
let token = 0;

export const isSpeaking = () => speaking;
export const onSpeakingChange = (fn) => listeners.push(fn);
const emit = (v) => {
  speaking = v;
  listeners.forEach((f) => f(v));
};

function chunk(text, max = 180) {
  const parts = text.split(/(?<=[.!?؟۔।\n])\s+/);
  const out = [];
  let cur = '';
  for (const p of parts) {
    if ((cur + ' ' + p).length > max && cur) {
      out.push(cur.trim());
      cur = p;
    } else {
      cur += ' ' + p;
    }
  }
  if (cur.trim()) out.push(cur.trim());
  return out.flatMap((c) => {
    if (c.length <= max * 1.6) return [c];
    const pieces = [];
    for (let i = 0; i < c.length; i += max) pieces.push(c.slice(i, i + max));
    return pieces;
  });
}

export function speak(text, lang, onDone) {
  if (!voiceSupport.synthesis) return false;
  const synth = window.speechSynthesis;
  synth.cancel();
  const myToken = ++token;
  const pieces = chunk(plainText(text));
  if (!pieces.length) return false;
  const voices = synth.getVoices();
  const base = (lang || '').split('-')[0];
  const voice = voices.find((v) => v.lang === lang) || voices.find((v) => v.lang && v.lang.split('-')[0] === base);
  let i = 0;
  const next = () => {
    if (myToken !== token) return;
    if (i >= pieces.length) {
      emit(false);
      onDone?.();
      return;
    }
    const u = new SpeechSynthesisUtterance(pieces[i++]);
    if (lang) u.lang = lang;
    if (voice) u.voice = voice;
    u.rate = 0.97;
    u.onend = next;
    u.onerror = () => {
      if (myToken === token) {
        emit(false);
        onDone?.();
      }
    };
    synth.speak(u);
  };
  emit(true);
  next();
  return true;
}

export function stopSpeaking() {
  if (!voiceSupport.synthesis) return;
  token++;
  window.speechSynthesis.cancel();
  if (speaking) emit(false);
}

export function voiceErrorMessage(code) {
  switch (code) {
    case 'unsupported':
      return 'Voice input is not supported in this browser. Please use Google Chrome or Microsoft Edge.';
    case 'not-allowed':
    case 'service-not-allowed':
      return 'Microphone permission was denied. Allow microphone access in your browser settings to use voice input.';
    case 'no-mic':
      return 'No microphone was found on this device.';
    case 'no-speech':
      return 'I did not hear anything. Tap the microphone and try again.';
    case 'network':
      return 'Voice recognition needs an internet connection.';
    default:
      return 'Voice input stopped unexpectedly. Please try again.';
  }
}
