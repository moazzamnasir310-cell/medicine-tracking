// Chat view: real-time messages, sending through the secure backend,
// retry (idempotent), pagination, copy, read-aloud.
import {
  collection,
  query,
  orderBy,
  limit,
  onSnapshot,
  getDocs,
  startAfter,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { httpsCallable } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js';
import { db, functions } from './firebase-config.js';
import { createConversation } from './conversation.js';
import { icon, LOGO_SVG, renderMarkdown, formatTime, formatDay, friendlyError, codeMessage, copyText, newId, toast } from './utils.js';
import { resolveLanguage, speechLang, t, getUiLang } from './language.js';
import * as voice from './voice.js';

export const MAX_LEN = 2000;
const PAGE_SIZE = 30;
const STALE_PROCESSING_MS = 120000;

const sendMessageFn = httpsCallable(functions, 'sendMessage', { timeout: 110000 });

const tsOf = (m) => (m.timestamp && m.timestamp.toMillis ? m.timestamp.toMillis() : m.ts || Date.now());

export class ChatView {
  /**
   * @param {object} o
   * @param {HTMLElement} o.container  message list element
   * @param {HTMLElement} o.scroller   scrollable wrapper
   * @param {HTMLElement} o.emptyEl    empty-state element
   * @param {(id:string|null)=>void} o.onConversationChange
   * @param {(busy:boolean)=>void} o.onBusyChange
   * @param {(err:Error)=>void} o.onFatal
   * @param {()=>string} o.getUid
   * @param {()=>string} o.getLanguagePref
   * @param {(near:boolean)=>void} o.onScrollState
   */
  constructor(o) {
    Object.assign(this, o);
    this.conversationId = null;
    this.unsub = null;
    this.token = 0;
    this.all = new Map();
    this.pending = new Map();
    this.failures = new Map();
    this.inflight = new Set();
    this.nodes = new Map();
    this.hasMore = false;
    this.loading = false;
    this.loadingOlder = false;
    this.initial = true;
    this.autoSpeak = false;
    this.speakingId = null;
    this.creating = false;

    this.container.addEventListener('click', (e) => this.onClick(e));
    this.scroller.addEventListener('scroll', () => this.onScrollState?.(this.nearBottom()), { passive: true });
    voice.onSpeakingChange((on) => {
      if (!on) this.speakingId = null;
      this.updateSpeakingUi();
    });
  }

  get busy() {
    return this.creating || this.inflight.size > 0;
  }

  setBusy() {
    this.onBusyChange?.(this.busy);
  }

  /* ----------------------------- Lifecycle ----------------------------- */
  open(id, { keepPending = false } = {}) {
    this.unsub?.();
    this.unsub = null;
    this.conversationId = id;
    this.all = new Map();
    if (!keepPending) {
      this.pending.clear();
      this.failures.clear();
      this.inflight.clear();
    }
    this.nodes.clear();
    this.hasMore = false;
    this.initial = true;
    this.loadingOlder = false;
    voice.stopSpeaking();
    const myToken = ++this.token;
    this.loading = !!id && !keepPending;
    this.render({ forceBottom: true });
    this.setBusy();
    if (!id) return;

    const q = query(collection(db, 'conversations', id, 'messages'), orderBy('timestamp', 'desc'), limit(PAGE_SIZE));
    this.unsub = onSnapshot(
      q,
      (snap) => {
        if (myToken === this.token) this.onSnapshot(snap);
      },
      (err) => {
        if (myToken !== this.token) return;
        this.loading = false;
        this.render();
        this.onFatal?.(err);
      }
    );
  }

  /** Stop listening (called on logout / screen close). */
  close() {
    this.unsub?.();
    this.unsub = null;
    this.token++;
    this.conversationId = null;
    this.all = new Map();
    this.pending.clear();
    this.failures.clear();
    this.inflight.clear();
    voice.stopSpeaking();
  }

  onSnapshot(snap) {
    const first = this.initial;
    if (snap.empty && this.all.size) this.all = new Map(); // conversation was cleared
    const spoken = [];
    snap.docChanges().forEach((ch) => {
      if (ch.type === 'removed') return; // docs leaving the live window stay in memory
      const d = ch.doc;
      const data = d.data({ serverTimestamps: 'estimate' });
      this.all.set(d.id, { id: d.id, ...data, _snap: d });
      if (!first && ch.type === 'added' && data.sender === 'assistant' && this.autoSpeak) spoken.push(d.id);
    });
    if (first) {
      this.initial = false;
      this.hasMore = snap.size >= PAGE_SIZE;
    }
    this.loading = false;
    this.render({ forceBottom: first });
    if (spoken.length) this.speak(spoken[spoken.length - 1]);
  }

  async loadOlder() {
    if (this.loadingOlder || !this.hasMore || !this.conversationId) return;
    this.loadingOlder = true;
    this.render();
    const prevHeight = this.scroller.scrollHeight;
    const myToken = this.token;
    try {
      const oldest = [...this.all.values()].filter((m) => m._snap).sort((a, b) => tsOf(a) - tsOf(b))[0];
      if (!oldest) {
        this.hasMore = false;
        return;
      }
      const snap = await getDocs(
        query(
          collection(db, 'conversations', this.conversationId, 'messages'),
          orderBy('timestamp', 'desc'),
          startAfter(oldest._snap),
          limit(PAGE_SIZE)
        )
      );
      if (myToken !== this.token) return;
      snap.docs.forEach((d) => this.all.set(d.id, { id: d.id, ...d.data({ serverTimestamps: 'estimate' }), _snap: d }));
      this.hasMore = snap.size >= PAGE_SIZE;
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      this.loadingOlder = false;
      this.render();
      this.scroller.scrollTop += this.scroller.scrollHeight - prevHeight;
    }
  }

  /* ------------------------------ Sending ------------------------------ */
  /**
   * @returns {Promise<boolean>} true when the message was accepted for sending
   */
  async send(rawText, { onAccepted } = {}) {
    const text = String(rawText || '').trim();
    if (!text || this.busy) return false;
    if (text.length > MAX_LEN) {
      toast(`Your message is too long. Please keep it under ${MAX_LEN} characters.`, 'error');
      return false;
    }
    if (!navigator.onLine) {
      toast('You are offline. Please reconnect to the internet and try again.', 'error');
      return false;
    }
    const uid = this.getUid();
    if (!uid) {
      toast('Please sign in to continue.', 'error');
      return false;
    }

    let convId = this.conversationId;
    if (!convId) {
      this.creating = true;
      this.setBusy();
      try {
        convId = await createConversation(uid, text);
      } catch (e) {
        this.creating = false;
        this.setBusy();
        toast(friendlyError(e), 'error');
        return false;
      }
      this.creating = false;
      this.open(convId, { keepPending: true });
      this.onConversationChange?.(convId);
    }

    const pref = this.getLanguagePref();
    const language = resolveLanguage(pref, text);
    const clientId = newId();
    this.pending.set(clientId, { id: clientId, sender: 'user', text, language, ts: Date.now(), status: 'sending' });
    onAccepted?.();
    this.deliver(convId, clientId, text, language, pref);
    return true;
  }

  async deliver(convId, clientId, text, language, pref) {
    this.inflight.add(clientId);
    this.failures.delete(clientId);
    const p = this.pending.get(clientId);
    if (p) {
      p.status = 'sending';
      p.error = null;
    }
    this.setBusy();
    this.render({ forceBottom: true });
    try {
      await sendMessageFn({ conversationId: convId, clientMessageId: clientId, text, language, preferredLanguage: pref });
      if (p) p.status = 'sent';
    } catch (err) {
      const msg = friendlyError(err);
      this.failures.set(clientId, msg);
      if (!this.all.has(clientId)) {
        const q = this.pending.get(clientId) || { id: clientId, sender: 'user', text, language, ts: Date.now() };
        q.status = 'failed';
        q.error = msg;
        this.pending.set(clientId, q);
      }
      toast(msg, 'error');
    } finally {
      this.inflight.delete(clientId);
      this.setBusy();
      this.render();
    }
  }

  retry(clientId) {
    if (this.busy || !this.conversationId) return;
    const m = this.all.get(clientId) || this.pending.get(clientId);
    if (!m) return;
    if (!navigator.onLine) {
      toast('You are offline. Please reconnect to the internet and try again.', 'error');
      return;
    }
    const pref = this.getLanguagePref();
    // Same clientId => the backend never creates a duplicate message.
    this.deliver(this.conversationId, clientId, m.text, m.language || resolveLanguage(pref, m.text), pref);
  }

  /* ------------------------------ Actions ------------------------------ */
  onClick(e) {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const id = btn.closest('[data-id]')?.dataset.id;
    switch (btn.dataset.action) {
      case 'copy': {
        const m = this.all.get(id) || this.pending.get(id);
        if (m) copyText(m.text).then((ok) => toast(ok ? 'Copied to clipboard' : 'Could not copy', ok ? 'success' : 'error', 1800));
        break;
      }
      case 'speak':
        this.speak(id, true);
        break;
      case 'retry':
        this.retry(id);
        break;
      case 'older':
        this.loadOlder();
        break;
      default:
    }
  }

  speak(id, toggle = false) {
    const m = this.all.get(id);
    if (!m) return;
    if (!voice.voiceSupport.synthesis) {
      toast('Read-aloud is not supported in this browser.', 'error');
      return;
    }
    if (toggle && this.speakingId === id && voice.isSpeaking()) {
      voice.stopSpeaking();
      return;
    }
    const code = m.language && m.language !== 'auto' ? m.language : resolveLanguage(this.getLanguagePref(), m.text);
    this.speakingId = id;
    voice.speak(m.text, speechLang(code));
    this.updateSpeakingUi();
  }

  updateSpeakingUi() {
    this.container.querySelectorAll('.msg').forEach((el) => {
      el.classList.toggle('is-speaking', el.dataset.id === this.speakingId && voice.isSpeaking());
    });
  }

  /* ------------------------------ Rendering ------------------------------ */
  nearBottom() {
    const s = this.scroller;
    return s.scrollHeight - s.scrollTop - s.clientHeight < 160;
  }

  scrollToBottom(smooth = true) {
    this.scroller.scrollTo({ top: this.scroller.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  }

  failedMessage(m) {
    return this.failures.get(m.id) || m.error || codeMessage(m.errorCode);
  }

  render({ forceBottom = false } = {}) {
    const wasNear = this.nearBottom();
    const hasContent = this.all.size > 0 || this.pending.size > 0;

    // Drop pending bubbles once the real document has arrived.
    for (const id of [...this.pending.keys()]) if (this.all.has(id)) this.pending.delete(id);

    const showEmpty = !this.loading && !hasContent;
    this.emptyEl.hidden = !showEmpty;
    this.container.hidden = showEmpty;
    if (showEmpty) {
      this.container.replaceChildren();
      this.nodes.clear();
      return;
    }

    if (this.loading) {
      this.container.replaceChildren(this.buildSkeleton());
      this.nodes.clear();
      return;
    }

    const list = [...this.all.values(), ...this.pending.values()].sort((a, b) => tsOf(a) - tsOf(b));
    const els = [];

    if (this.hasMore) {
      const more = document.createElement('div');
      more.className = 'load-older';
      more.innerHTML = `<button type="button" class="btn btn-soft" data-action="older" ${this.loadingOlder ? 'disabled' : ''}>${
        this.loadingOlder ? '<span class="spinner"></span>' : icon('chevronDown', 16)
      }<span>${t('loadOlder')}</span></button>`;
      els.push(more);
    }

    let lastDay = '';
    let awaitingAi = false;
    const aiIds = new Set(list.filter((m) => m.sender === 'assistant').map((m) => m.id));
    const keep = new Set();

    for (const m of list) {
      const ts = tsOf(m);
      const day = new Date(ts).toDateString();
      if (day !== lastDay) {
        lastDay = day;
        const sep = document.createElement('div');
        sep.className = 'day-sep';
        sep.innerHTML = `<span>${formatDay(ts, getUiLang())}</span>`;
        els.push(sep);
      }
      const stale = m.status === 'processing' && Date.now() - (m.processingAtMs || 0) > STALE_PROCESSING_MS;
      const inflight = this.inflight.has(m.id);
      const failed = !inflight && (m.status === 'failed' || stale);
      const processing = m.sender === 'user' && !aiIds.has(`${m.id}_ai`) && !failed && (inflight || m.status === 'processing' || m.status === 'sending');
      if (processing) awaitingAi = true;
      const errText = failed ? (stale && !this.failures.has(m.id) ? codeMessage('timeout') : this.failedMessage(m)) : '';
      const sig = [m.text, failed, processing, errText, ts, getUiLang()].join('\u0001');
      keep.add(m.id);
      let node = this.nodes.get(m.id);
      if (!node || node.sig !== sig) {
        node = { sig, el: this.buildMessage(m, { failed, processing, errText, ts }) };
        this.nodes.set(m.id, node);
      }
      els.push(node.el);
    }
    for (const id of this.nodes.keys()) if (!keep.has(id)) this.nodes.delete(id);

    if (awaitingAi) els.push(this.buildTyping());

    this.container.replaceChildren(...els);
    this.updateSpeakingUi();
    if (forceBottom || wasNear) this.scrollToBottom(!forceBottom);
    this.onScrollState?.(this.nearBottom());
  }

  buildMessage(m, { failed, processing, errText, ts }) {
    const isUser = m.sender === 'user';
    const el = document.createElement('article');
    el.className = `msg ${isUser ? 'msg-user' : 'msg-ai'}${failed ? ' is-failed' : ''}`;
    el.dataset.id = m.id;

    const body = document.createElement('div');
    body.className = 'msg-body';
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.setAttribute('dir', 'auto');
    if (isUser) bubble.textContent = m.text;
    else bubble.innerHTML = renderMarkdown(m.text);
    body.appendChild(bubble);

    const meta = document.createElement('div');
    meta.className = 'msg-meta';
    const time = document.createElement('time');
    time.textContent = formatTime(ts, getUiLang());
    meta.appendChild(time);
    if (isUser && processing && m.status === 'sending') {
      const s = document.createElement('span');
      s.className = 'msg-status';
      s.innerHTML = `${icon('clock', 13)}<span>Sending…</span>`;
      meta.appendChild(s);
    }
    const actions = document.createElement('span');
    actions.className = 'msg-actions';
    actions.innerHTML =
      `<button type="button" class="icon-btn sm" data-action="copy" title="Copy" aria-label="Copy message">${icon('copy', 15)}</button>` +
      (isUser
        ? ''
        : `<button type="button" class="icon-btn sm speak-btn" data-action="speak" title="Read aloud / repeat" aria-label="Read answer aloud">${icon('volume', 15)}</button>`);
    meta.appendChild(actions);
    body.appendChild(meta);

    if (failed) {
      const err = document.createElement('div');
      err.className = 'msg-error';
      err.setAttribute('role', 'alert');
      err.innerHTML = `${icon('alert', 16)}<span></span><button type="button" class="btn btn-soft sm" data-action="retry">${icon('retry', 14)}<span>${t('retry')}</span></button>`;
      err.querySelector('span').textContent = errText;
      body.appendChild(err);
    }

    if (!isUser) {
      const av = document.createElement('div');
      av.className = 'avatar-ai';
      av.setAttribute('aria-hidden', 'true');
      av.innerHTML = LOGO_SVG;
      el.appendChild(av);
    }
    el.appendChild(body);
    return el;
  }

  buildTyping() {
    const el = document.createElement('div');
    el.className = 'msg msg-ai typing';
    el.setAttribute('aria-label', 'AI Doctor is typing');
    el.innerHTML = `<div class="avatar-ai" aria-hidden="true">${LOGO_SVG}</div><div class="msg-body"><div class="bubble"><span class="dots"><i></i><i></i><i></i></span></div></div>`;
    return el;
  }

  buildSkeleton() {
    const wrap = document.createElement('div');
    wrap.className = 'skeleton-wrap';
    wrap.setAttribute('aria-busy', 'true');
    wrap.innerHTML =
      '<div class="sk sk-ai"></div><div class="sk sk-user"></div><div class="sk sk-ai tall"></div><div class="sk sk-user short"></div>';
    return wrap;
  }
}
