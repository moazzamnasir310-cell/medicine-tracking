// Language selection, detection and UI translations.

export const LANGUAGES = [
  { code: 'auto', label: 'Auto detect', speech: '', rtl: false },
  { code: 'en', label: 'English', speech: 'en-US', rtl: false },
  { code: 'ur', label: 'اردو (Urdu)', speech: 'ur-PK', rtl: true },
  { code: 'roman-ur', label: 'Roman Urdu', speech: 'en-PK', rtl: false },
  { code: 'hi', label: 'हिन्दी (Hindi)', speech: 'hi-IN', rtl: false },
  { code: 'ar', label: 'العربية (Arabic)', speech: 'ar-SA', rtl: true },
  { code: 'pa', label: 'ਪੰਜਾਬੀ (Punjabi)', speech: 'pa-IN', rtl: false },
];

export const VALID_CODES = LANGUAGES.map((l) => l.code);

const ROMAN_URDU_WORDS = new Set(
  'kya hai hain mujhe mujhay mujhko meri mera mere kaise kese kaisay dawai dawa dawaiyan bukhar dard nahi nahin aur sar pait batao bataye bataiye kitni kitna khana khane kab kyun kyu hota hoti hoga hogi lena lein leni chahiye chahye tabiyat ilaj bimari zukam khansi gala neend'.split(' ')
);

/** Best-effort script/word based detection used for voice, TTS and RTL hints. */
export function detectLanguage(text) {
  const s = String(text || '');
  if (/[਀-੿]/.test(s)) return 'pa';
  if (/[ऀ-ॿ]/.test(s)) return 'hi';
  if (/[؀-ۿ]/.test(s)) {
    return /[ٹڈڑںےھہگچپژکی]/.test(s) ? 'ur' : 'ar';
  }
  const words = s.toLowerCase().match(/[a-z]+/g) || [];
  let hits = 0;
  for (const w of words) if (ROMAN_URDU_WORDS.has(w)) hits++;
  if (hits >= 2) return 'roman-ur';
  return 'en';
}

export const resolveLanguage = (selection, text) => (selection && selection !== 'auto' ? selection : detectLanguage(text));

export function speechLang(code) {
  const l = LANGUAGES.find((x) => x.code === code);
  return (l && l.speech) || navigator.language || 'en-US';
}

export const isRtl = (code) => !!(LANGUAGES.find((x) => x.code === code) || {}).rtl;

/* --------------------------- UI strings --------------------------- */
const I18N = {
  en: {
    appTagline: 'Your trusted AI health assistant',
    continueGoogle: 'Continue with Google',
    newChat: 'New chat',
    searchChats: 'Search chats…',
    history: 'Chat history',
    placeholder: 'Ask about medicines, symptoms or healthy habits…',
    emptyTitle: "Hello! I'm your AI Health Assistant",
    emptySub: 'Ask me about medicines, side effects, interactions or healthy habits. I share general health information, not a diagnosis.',
    language: 'Language',
    readAloud: 'Read answers aloud',
    deleteAll: 'Delete all chats',
    logout: 'Log out',
    online: 'Online',
    offline: 'You are offline. Messages will not send until you reconnect.',
    disclaimer: 'General health information only — not a medical diagnosis. In an emergency call your local emergency number.',
    loadOlder: 'Load older messages',
    retry: 'Retry',
    noChats: 'No conversations yet',
    admin: 'Admin panel',
  },
  ur: {
    appTagline: 'آپ کا قابلِ اعتماد اے آئی ہیلتھ اسسٹنٹ',
    continueGoogle: 'گوگل کے ساتھ جاری رکھیں',
    newChat: 'نئی چیٹ',
    searchChats: 'چیٹس تلاش کریں…',
    history: 'چیٹ کی تاریخ',
    placeholder: 'ادویات، علامات یا صحت مند عادات کے بارے میں پوچھیں…',
    emptyTitle: 'السلام علیکم! میں آپ کا اے آئی ہیلتھ اسسٹنٹ ہوں',
    emptySub: 'ادویات، مضر اثرات، باہمی اثرات یا صحت مند عادات کے بارے میں پوچھیں۔ میں عمومی معلومات دیتا ہوں، تشخیص نہیں۔',
    language: 'زبان',
    readAloud: 'جوابات بلند آواز میں سنائیں',
    deleteAll: 'تمام چیٹس حذف کریں',
    logout: 'لاگ آؤٹ',
    online: 'آن لائن',
    offline: 'آپ آف لائن ہیں۔ انٹرنیٹ بحال ہونے تک پیغام نہیں جائے گا۔',
    disclaimer: 'صرف عمومی صحت کی معلومات — طبی تشخیص نہیں۔ ایمرجنسی میں فوراً مقامی ایمرجنسی نمبر پر کال کریں۔',
    loadOlder: 'پرانے پیغامات لوڈ کریں',
    retry: 'دوبارہ کوشش کریں',
    noChats: 'ابھی کوئی گفتگو نہیں',
    admin: 'ایڈمن پینل',
  },
  ar: {
    appTagline: 'مساعدك الصحي الذكي الموثوق',
    continueGoogle: 'المتابعة باستخدام Google',
    newChat: 'محادثة جديدة',
    searchChats: 'ابحث في المحادثات…',
    history: 'سجل المحادثات',
    placeholder: 'اسأل عن الأدوية أو الأعراض أو العادات الصحية…',
    emptyTitle: 'مرحبًا! أنا مساعدك الصحي الذكي',
    emptySub: 'اسأل عن الأدوية وآثارها الجانبية وتداخلاتها والعادات الصحية. أقدّم معلومات عامة وليس تشخيصًا.',
    language: 'اللغة',
    readAloud: 'قراءة الإجابات بصوت عالٍ',
    deleteAll: 'حذف كل المحادثات',
    logout: 'تسجيل الخروج',
    online: 'متصل',
    offline: 'أنت غير متصل. لن تُرسل الرسائل حتى يعود الاتصال.',
    disclaimer: 'معلومات صحية عامة فقط وليست تشخيصًا طبيًا. في الطوارئ اتصل برقم الطوارئ المحلي.',
    loadOlder: 'تحميل الرسائل الأقدم',
    retry: 'إعادة المحاولة',
    noChats: 'لا توجد محادثات بعد',
    admin: 'لوحة المشرف',
  },
  hi: {
    appTagline: 'आपका भरोसेमंद AI हेल्थ असिस्टेंट',
    continueGoogle: 'Google के साथ जारी रखें',
    newChat: 'नई चैट',
    searchChats: 'चैट खोजें…',
    history: 'चैट इतिहास',
    placeholder: 'दवाओं, लक्षणों या स्वस्थ आदतों के बारे में पूछें…',
    emptyTitle: 'नमस्ते! मैं आपका AI हेल्थ असिस्टेंट हूँ',
    emptySub: 'दवाओं, साइड इफ़ेक्ट, इंटरैक्शन या स्वस्थ आदतों के बारे में पूछें। मैं सामान्य जानकारी देता हूँ, निदान नहीं।',
    language: 'भाषा',
    readAloud: 'उत्तर ज़ोर से पढ़ें',
    deleteAll: 'सभी चैट हटाएँ',
    logout: 'लॉग आउट',
    online: 'ऑनलाइन',
    offline: 'आप ऑफ़लाइन हैं। इंटरनेट लौटने तक संदेश नहीं जाएँगे।',
    disclaimer: 'केवल सामान्य स्वास्थ्य जानकारी — चिकित्सीय निदान नहीं। आपात स्थिति में स्थानीय आपातकालीन नंबर पर कॉल करें।',
    loadOlder: 'पुराने संदेश लोड करें',
    retry: 'दोबारा कोशिश करें',
    noChats: 'अभी कोई बातचीत नहीं',
    admin: 'एडमिन पैनल',
  },
};

let uiLang = 'en';

export const getUiLang = () => uiLang;

export function t(key) {
  return (I18N[uiLang] && I18N[uiLang][key]) || I18N.en[key] || key;
}

/** Apply a UI language (falls back to English for languages without UI strings). */
export function setUiLanguage(code) {
  uiLang = I18N[code] ? code : 'en';
  const root = document.documentElement;
  root.lang = uiLang;
  root.dir = isRtl(uiLang) ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    el.placeholder = t(el.dataset.i18nPlaceholder);
  });
  document.querySelectorAll('[data-i18n-label]').forEach((el) => {
    el.setAttribute('aria-label', t(el.dataset.i18nLabel));
  });
}
