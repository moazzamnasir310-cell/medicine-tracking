// Firebase initialisation (CDN ES modules — no bundler needed).
// NOTE: a Firebase *web* config (apiKey etc.) is NOT a secret. Security comes from
// Firestore rules + Authentication. The Gemini key is never in the browser.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { getFunctions } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js';
import { getAnalytics, isSupported } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-analytics.js';

export const firebaseConfig = {
  apiKey: 'AIzaSyDC6adBShkztaarDc_gp4qGO1OvPMoDVXI',
  authDomain: 'medicine-tracking-87531.firebaseapp.com',
  databaseURL: 'https://medicine-tracking-87531-default-rtdb.firebaseio.com',
  projectId: 'medicine-tracking-87531',
  storageBucket: 'medicine-tracking-87531.firebasestorage.app',
  messagingSenderId: '202888754235',
  appId: '1:202888754235:web:cc07a5cda8f911ae70d81e',
  measurementId: 'G-JG47HNEBZ9',
};

export const FUNCTIONS_REGION = 'us-central1';

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Offline cache: messages already loaded stay readable without internet and
// Firestore reconnects automatically. Falls back gracefully if unsupported.
let _db;
try {
  _db = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
  });
} catch (e) {
  console.warn('Persistent cache unavailable, using default Firestore.', e);
  _db = getFirestore(app);
}
export const db = _db;

export const functions = getFunctions(app, FUNCTIONS_REGION);

// Analytics is optional and only runs where supported.
isSupported()
  .then((ok) => {
    if (ok) getAnalytics(app);
  })
  .catch(() => {});
