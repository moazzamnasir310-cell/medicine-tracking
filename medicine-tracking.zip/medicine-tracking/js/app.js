// Application bootstrap: wires auth, sidebar, chat, voice, admin, theme.
import { doc, onSnapshot } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { db } from './firebase-config.js';
import { watchAuth, signInWithGoogle, logout, savePreferredLanguage } from './auth.js';
import {
  subscribeConversations,
  renameConversation,
  deleteConversation,
  clearConversation,
  deleteAllConversations,
} from './conversation.js';
import { ChatView, MAX_LEN } from './chat.js';
import { LANGUAGES, VALID_CODES, setUiLanguage, resolveLanguage, speechLang, t } from './language.js';
import * as voice from './voice.js';
import { initAdmin, openAdmin, closeAdmin } from './admin.js';
import { $, $$, icon, hydrateIcons, LOGO_SVG, toast, friendlyError, confirmDialog, promptDialog, escapeHtml, debounce } from './utils.js';

/* ------------------------------ State ------------------------------ */
const state = {
  user: null,
  profile: null,
  isAdmin: false,
  conversations: [],
  currentId: null,
  search: '',
  aiEnabled: true,
  announcement: '',
  announcementStamp: 0,
  langPref: localStorage.getItem('mt-lang') || 'auto',
  unsubConvs: null,
  unsubConfig: null,
};

const el = {};
let chat;
let voiceInput;
let baseInputText = '';

/* ------------------------------ Boot ------------------------------ */
document.addEventListener('DOMContentLoaded', () => {
  [
    'boot', 'login-view', 'app-view', 'sidebar', 'scrim', 'conv-list', 'conv-search', 'new-chat-btn', 'lang-select',
    'autospeak-toggle', 'delete-all-btn', 'admin-btn', 'user-avatar', 'user-name', 'user-email', 'logout-btn',
    'menu-btn', 'sb-close', 'chat-title', 'rename-btn', 'clear-btn', 'delete-btn', 'theme-btn', 'stop-speak-btn',
    'banner-offline', 'banner-announce', 'announce-text', 'announce-close', 'banner-disabled', 'messages-wrap',
    'messages', 'empty-state', 'composer', 'msg-input', 'send-btn', 'mic-btn', 'char-count', 'listening-pill',
    'scroll-down', 'google-btn', 'login-error', 'suggestions',
  ].forEach((id) => (el[id] = document.getElementById(id)));

  hydrateIcons();
  $$('.brand-logo, .doctor-avatar').forEach((n) => (n.innerHTML = LOGO_SVG));
  initTheme();
  initLanguageSelect();
  setUiLanguage(uiLangFor(state.langPref));
  initChat();
  initEvents();
  initAdmin();
  registerServiceWorker();

  watchAuth(onAuth);
});

function registerServiceWorker() {
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('service-worker.js').catch(() => {});
  }
}

const uiLangFor = (code) => (['en', 'ur', 'ar', 'hi'].includes(code) ? code : 'en');

/* ------------------------------ Theme ------------------------------ */
function initTheme() {
  applyTheme(document.documentElement.dataset.theme || 'light');
  el['theme-btn'].addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try {
      localStorage.setItem('mt-theme', next);
    } catch {
      /* ignore */
    }
  });
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  el['theme-btn'].innerHTML = icon(theme === 'dark' ? 'sun' : 'moon', 18);
  el['theme-btn'].setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.content = theme === 'dark' ? '#0b1522' : '#0b6fd6';
}

/* ------------------------------ Language ------------------------------ */
function initLanguageSelect() {
  el['lang-select'].innerHTML = LANGUAGES.map((l) => `<option value="${l.code}">${escapeHtml(l.label)}</option>`).join('');
  el['lang-select'].value = VALID_CODES.includes(state.langPref) ? state.langPref : 'auto';
  el['lang-select'].addEventListener('change', async () => {
    state.langPref = el['lang-select'].value;
    try {
      localStorage.setItem('mt-lang', state.langPref);
    } catch {
      /* ignore */
    }
    setUiLanguage(uiLangFor(state.langPref));
    renderConversations();
    updateHeader();
    if (state.user) savePreferredLanguage(state.user.uid, state.langPref).catch(() => {});
  });
}

/* ------------------------------ Auth ------------------------------ */
function onAuth(result, errorMessage) {
  el.boot.hidden = true;
  if (!result) {
    teardown();
    el['app-view'].hidden = true;
    el['login-view'].hidden = false;
    if (errorMessage) showLoginError(errorMessage);
    return;
  }
  const { user, profile, isAdmin } = result;
  state.user = user;
  state.profile = profile;
  state.isAdmin = isAdmin;
  state.langPref = profile.preferredLanguage || state.langPref;
  el['lang-select'].value = state.langPref;
  setUiLanguage(uiLangFor(state.langPref));

  el['login-view'].hidden = true;
  el['app-view'].hidden = false;
  el['user-name'].textContent = profile.displayName || user.displayName || 'User';
  el['user-email'].textContent = profile.email || user.email || '';
  const avatar = el['user-avatar'];
  if (profile.photoURL) {
    avatar.innerHTML = '';
    const img = new Image();
    img.src = profile.photoURL;
    img.alt = '';
    img.referrerPolicy = 'no-referrer';
    img.onerror = () => (avatar.textContent = (profile.displayName || 'U').charAt(0).toUpperCase());
    avatar.appendChild(img);
  } else {
    avatar.textContent = (profile.displayName || 'U').charAt(0).toUpperCase();
  }
  el['admin-btn'].hidden = !isAdmin;

  startListeners();
  selectConversation(null);
  updateOnlineBanner();
  el['msg-input'].focus({ preventScroll: true });
}

function showLoginError(msg) {
  el['login-error'].textContent = msg;
  el['login-error'].hidden = !msg;
}

function startListeners() {
  teardown();
  el['conv-list'].innerHTML = '<div class="conv-skeleton"></div><div class="conv-skeleton"></div><div class="conv-skeleton"></div>';
  state.unsubConvs = subscribeConversations(
    state.user.uid,
    (list) => {
      state.conversations = list;
      renderConversations();
      updateHeader();
    },
    (err) => {
      el['conv-list'].innerHTML = '';
      toast(friendlyError(err), 'error');
    }
  );
  state.unsubConfig = onSnapshot(
    doc(db, 'appConfig', 'public'),
    (snap) => {
      const c = snap.exists() ? snap.data() : {};
      state.aiEnabled = c.aiEnabled !== false;
      state.announcement = c.announcement || '';
      state.announcementStamp = c.announcementUpdatedAt || 0;
      applyConfigBanners();
    },
    () => {
      /* config is optional; ignore errors */
    }
  );
}

function teardown() {
  state.unsubConvs?.();
  state.unsubConfig?.();
  state.unsubConvs = state.unsubConfig = null;
  state.conversations = [];
  state.currentId = null;
  chat?.close();
  voice.stopSpeaking();
  voiceInput?.stop();
}

function applyConfigBanners() {
  const dismissed = Number(sessionStorage.getItem('mt-announce-dismissed') || 0);
  const show = !!state.announcement && dismissed !== state.announcementStamp;
  el['banner-announce'].hidden = !show;
  el['announce-text'].textContent = state.announcement;
  el['banner-disabled'].hidden = state.aiEnabled;
  if (!state.aiEnabled) el['banner-disabled'].innerHTML = `${icon('alert', 18)}<span>AI chat is temporarily disabled by the administrator.</span>`;
  updateComposerState();
}

/* ------------------------------ Chat setup ------------------------------ */
function initChat() {
  chat = new ChatView({
    container: el.messages,
    scroller: el['messages-wrap'],
    emptyEl: el['empty-state'],
    getUid: () => state.user && state.user.uid,
    getLanguagePref: () => state.langPref,
    onConversationChange: (id) => {
      state.currentId = id;
      renderConversations();
      updateHeader();
    },
    onBusyChange: () => updateComposerState(),
    onScrollState: (near) => (el['scroll-down'].hidden = near),
    onFatal: (err) => {
      toast(friendlyError(err), 'error');
      if (err && err.code === 'permission-denied') selectConversation(null);
    },
  });
}

function selectConversation(id) {
  state.currentId = id;
  chat.open(id);
  renderConversations();
  updateHeader();
  closeSidebar();
}

function currentConversation() {
  return state.conversations.find((c) => c.id === state.currentId) || null;
}

function updateHeader() {
  const c = currentConversation();
  el['chat-title'].textContent = state.currentId ? (c ? c.title : '…') : t('newChat');
  const has = !!state.currentId;
  el['rename-btn'].hidden = el['clear-btn'].hidden = el['delete-btn'].hidden = !has;
}

function updateComposerState() {
  const busy = chat && chat.busy;
  const offline = !navigator.onLine;
  const text = el['msg-input'].value.trim();
  const disabled = !state.aiEnabled;
  el['msg-input'].disabled = disabled;
  el['mic-btn'].disabled = disabled;
  el['send-btn'].disabled = disabled || busy || offline || !text;
  el['send-btn'].classList.toggle('loading', !!busy);
  el['send-btn'].innerHTML = busy ? '<span class="spinner light"></span>' : icon('send', 20);
  el['new-chat-btn'].disabled = false;
}

function updateOnlineBanner() {
  el['banner-offline'].hidden = navigator.onLine;
  el['banner-offline'].innerHTML = `${icon('alert', 18)}<span>${escapeHtml(t('offline'))}</span>`;
  updateComposerState();
}

/* ------------------------------ Sidebar list ------------------------------ */
function groupLabel(ms) {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const day = 86400000;
  if (ms >= startOfToday) return 'Today';
  if (ms >= startOfToday - day) return 'Yesterday';
  if (ms >= startOfToday - 7 * day) return 'Previous 7 days';
  return 'Older';
}

function renderConversations() {
  const q = state.search.trim().toLowerCase();
  const list = state.conversations.filter((c) => !q || c.title.toLowerCase().includes(q) || c.lastMessage.toLowerCase().includes(q));
  const root = el['conv-list'];
  if (!list.length) {
    root.innerHTML = `<div class="conv-empty">${icon('pill', 28)}<p>${escapeHtml(q ? 'No matching chats' : t('noChats'))}</p></div>`;
    return;
  }
  let html = '';
  let last = '';
  for (const c of list) {
    const g = groupLabel(c.updatedAt);
    if (g !== last) {
      html += `<div class="conv-group">${g}</div>`;
      last = g;
    }
    html += `<div class="conv-item${c.id === state.currentId ? ' active' : ''}" data-id="${c.id}">
      <button type="button" class="conv-main" data-act="open" title="${escapeHtml(c.title)}">
        <span class="conv-title" dir="auto">${escapeHtml(c.title)}</span>
        <span class="conv-last" dir="auto">${escapeHtml(c.lastMessage || '')}</span>
      </button>
      <span class="conv-actions">
        <button type="button" class="icon-btn sm" data-act="rename" aria-label="Rename chat">${icon('edit', 15)}</button>
        <button type="button" class="icon-btn sm danger" data-act="delete" aria-label="Delete chat">${icon('trash', 15)}</button>
      </span>
    </div>`;
  }
  root.innerHTML = html;
}

function openSidebar() {
  el.sidebar.classList.add('open');
  el.scrim.hidden = false;
}
function closeSidebar() {
  el.sidebar.classList.remove('open');
  el.scrim.hidden = true;
}

/* ------------------------------ Actions ------------------------------ */
async function doRename(id) {
  const c = state.conversations.find((x) => x.id === id);
  if (!c) return;
  const title = await promptDialog({ title: 'Rename chat', label: 'Chat name', value: c.title, confirmText: 'Save' });
  if (!title || title === c.title) return;
  try {
    await renameConversation(id, title);
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

async function doDelete(id) {
  const ok = await confirmDialog({
    title: 'Delete this chat?',
    message: 'This permanently deletes the conversation and all its messages. This cannot be undone.',
    confirmText: 'Delete',
    danger: true,
  });
  if (!ok) return;
  try {
    await deleteConversation(id);
    if (state.currentId === id) selectConversation(null);
    toast('Conversation deleted', 'success');
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

async function doClear() {
  if (!state.currentId) return;
  const ok = await confirmDialog({
    title: 'Clear this conversation?',
    message: 'All messages in this chat will be permanently deleted. The chat itself stays in your list.',
    confirmText: 'Clear messages',
    danger: true,
  });
  if (!ok) return;
  try {
    await clearConversation(state.currentId);
    toast('Conversation cleared', 'success');
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

async function doDeleteAll() {
  if (!state.conversations.length) {
    toast('You have no conversations to delete.', 'info');
    return;
  }
  const ok = await confirmDialog({
    title: 'Delete ALL chats?',
    message: 'Every conversation and message in your account will be permanently deleted. This cannot be undone.',
    confirmText: 'Delete everything',
    danger: true,
  });
  if (!ok) return;
  try {
    await deleteAllConversations();
    selectConversation(null);
    toast('All conversations deleted', 'success');
  } catch (e) {
    toast(friendlyError(e), 'error');
  }
}

/* ------------------------------ Composer ------------------------------ */
function autosize() {
  const ta = el['msg-input'];
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 170) + 'px';
  const len = ta.value.length;
  el['char-count'].textContent = `${len}/${MAX_LEN}`;
  el['char-count'].classList.toggle('over', len > MAX_LEN);
  updateComposerState();
}

async function submitMessage(textOverride) {
  const text = typeof textOverride === 'string' ? textOverride : el['msg-input'].value;
  if (voiceInput?.active) voiceInput.stop();
  voice.stopSpeaking();
  const accepted = await chat.send(text, {
    onAccepted: () => {
      el['msg-input'].value = '';
      autosize();
    },
  });
  if (accepted) el['msg-input'].focus({ preventScroll: true });
}

function initVoice() {
  if (voiceInput) return voiceInput;
  voiceInput = new voice.VoiceInput({
    onStart: () => {
      el['mic-btn'].classList.add('listening');
      el['mic-btn'].setAttribute('aria-pressed', 'true');
      el['listening-pill'].hidden = false;
    },
    onEnd: () => {
      el['mic-btn'].classList.remove('listening');
      el['mic-btn'].setAttribute('aria-pressed', 'false');
      el['listening-pill'].hidden = true;
      el['msg-input'].focus({ preventScroll: true });
    },
    onText: (text) => {
      // Recognised speech goes into the box so the user can edit before sending.
      el['msg-input'].value = (baseInputText ? baseInputText + ' ' : '') + text;
      autosize();
    },
    onError: (code) => toast(voice.voiceErrorMessage(code), code === 'no-speech' ? 'info' : 'error'),
  });
  return voiceInput;
}

function toggleMic() {
  if (!voice.voiceSupport.recognition) {
    toast(voice.voiceErrorMessage('unsupported'), 'error');
    return;
  }
  const vi = initVoice();
  if (vi.active) {
    vi.stop();
    return;
  }
  voice.stopSpeaking();
  baseInputText = el['msg-input'].value.trim();
  const sample = baseInputText;
  const code = state.langPref !== 'auto' ? state.langPref : resolveLanguage('auto', sample) !== 'en' ? resolveLanguage('auto', sample) : 'en';
  vi.start(speechLang(state.langPref === 'auto' && code === 'en' ? 'en' : code));
}

/* ------------------------------ Events ------------------------------ */
function initEvents() {
  el['google-btn'].addEventListener('click', async () => {
    showLoginError('');
    el['google-btn'].disabled = true;
    el['google-btn'].classList.add('loading');
    const err = await signInWithGoogle();
    el['google-btn'].disabled = false;
    el['google-btn'].classList.remove('loading');
    if (err) showLoginError(err);
  });

  el['logout-btn'].addEventListener('click', async () => {
    try {
      teardown();
      await logout();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  });

  el['new-chat-btn'].addEventListener('click', () => {
    selectConversation(null);
    el['msg-input'].focus();
  });
  el['menu-btn'].addEventListener('click', openSidebar);
  el['sb-close'].addEventListener('click', closeSidebar);
  el.scrim.addEventListener('click', closeSidebar);

  el['conv-search'].addEventListener(
    'input',
    debounce(() => {
      state.search = el['conv-search'].value;
      renderConversations();
    }, 150)
  );

  el['conv-list'].addEventListener('click', (e) => {
    const btn = e.target.closest('[data-act]');
    const item = e.target.closest('.conv-item');
    if (!btn || !item) return;
    const id = item.dataset.id;
    if (btn.dataset.act === 'open') {
      if (id !== state.currentId) selectConversation(id);
      else closeSidebar();
    } else if (btn.dataset.act === 'rename') doRename(id);
    else if (btn.dataset.act === 'delete') doDelete(id);
  });

  el['rename-btn'].addEventListener('click', () => state.currentId && doRename(state.currentId));
  el['delete-btn'].addEventListener('click', () => state.currentId && doDelete(state.currentId));
  el['clear-btn'].addEventListener('click', doClear);
  el['delete-all-btn'].addEventListener('click', doDeleteAll);
  el['admin-btn'].addEventListener('click', openAdmin);

  el['autospeak-toggle'].checked = localStorage.getItem('mt-autospeak') === '1';
  chat.autoSpeak = el['autospeak-toggle'].checked;
  el['autospeak-toggle'].addEventListener('change', () => {
    chat.autoSpeak = el['autospeak-toggle'].checked;
    localStorage.setItem('mt-autospeak', chat.autoSpeak ? '1' : '0');
    if (!chat.autoSpeak) voice.stopSpeaking();
  });
  voice.onSpeakingChange((on) => (el['stop-speak-btn'].hidden = !on));
  el['stop-speak-btn'].addEventListener('click', () => voice.stopSpeaking());

  el['announce-close'].addEventListener('click', () => {
    sessionStorage.setItem('mt-announce-dismissed', String(state.announcementStamp));
    el['banner-announce'].hidden = true;
  });

  el['composer'].addEventListener('submit', (e) => {
    e.preventDefault();
    submitMessage();
  });
  el['msg-input'].addEventListener('input', autosize);
  el['msg-input'].addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      if (!el['send-btn'].disabled) submitMessage();
    }
  });
  el['mic-btn'].addEventListener('click', toggleMic);

  el['scroll-down'].addEventListener('click', () => chat.scrollToBottom(true));

  el.suggestions.addEventListener('click', (e) => {
    const b = e.target.closest('[data-prompt]');
    if (b && state.aiEnabled && !chat.busy) submitMessage(b.dataset.prompt);
  });

  window.addEventListener('online', () => {
    updateOnlineBanner();
    toast('Back online', 'success', 2000);
  });
  window.addEventListener('offline', updateOnlineBanner);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeSidebar();
      if (!$('#admin-view').hidden) closeAdmin();
    }
  });

  // Release listeners when the page is closed.
  window.addEventListener('pagehide', () => {
    voice.stopSpeaking();
    state.unsubConvs?.();
    state.unsubConfig?.();
    chat?.close();
  });

  if (!voice.voiceSupport.recognition) el['mic-btn'].title = 'Voice input is not supported in this browser';
  autosize();
}
