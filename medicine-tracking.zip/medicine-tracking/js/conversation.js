// Conversation list + management (create, rename, delete, clear).
import {
  collection,
  doc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  setDoc,
  updateDoc,
  serverTimestamp,
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import { httpsCallable } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js';
import { db, functions } from './firebase-config.js';

export const CONVERSATION_LIMIT = 50;

export function deriveTitle(text) {
  const t = String(text).replace(/\s+/g, ' ').trim();
  return t.length > 40 ? t.slice(0, 40).trimEnd() + '…' : t || 'New chat';
}

/** Real-time list of the signed-in user's conversations (newest first). */
export function subscribeConversations(uid, onData, onError) {
  const q = query(
    collection(db, 'conversations'),
    where('userId', '==', uid),
    orderBy('updatedAt', 'desc'),
    limit(CONVERSATION_LIMIT)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(
        snap.docs.map((d) => {
          const v = d.data({ serverTimestamps: 'estimate' });
          return {
            id: d.id,
            title: v.title || 'New chat',
            lastMessage: v.lastMessage || '',
            updatedAt: v.updatedAt ? v.updatedAt.toMillis() : Date.now(),
          };
        })
      );
    },
    onError
  );
}

/** Created lazily on the first message so no empty chats pile up. */
export async function createConversation(uid, title) {
  const ref = doc(collection(db, 'conversations'));
  await setDoc(ref, {
    conversationId: ref.id,
    userId: uid,
    title: deriveTitle(title),
    lastMessage: '',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function renameConversation(id, title) {
  const clean = String(title).trim().slice(0, 80);
  if (!clean) return;
  await updateDoc(doc(db, 'conversations', id), { title: clean, updatedAt: serverTimestamp() });
}

const deleteFn = httpsCallable(functions, 'deleteConversation', { timeout: 120000 });
const clearFn = httpsCallable(functions, 'clearConversation', { timeout: 120000 });
const deleteAllFn = httpsCallable(functions, 'deleteAllConversations', { timeout: 300000 });

export const deleteConversation = (id) => deleteFn({ conversationId: id });
export const clearConversation = (id) => clearFn({ conversationId: id });
export const deleteAllConversations = () => deleteAllFn({});
