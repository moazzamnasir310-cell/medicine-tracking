# Medicine Tracking — AI Health Assistant (Firebase + Gemini)

Vanilla HTML/CSS/JavaScript (ES Modules) frontend, Firebase Auth + Firestore + Cloud Functions + Hosting.
Gemini API key sirf server (Secret Manager) mein rehti hai — browser mein kabhi nahi.

> **Project ID:** `medicine-tracking-87531` (already `.firebaserc` aur `js/firebase-config.js` mein set hai)

---

## 1. Files kahan rakhni hain

```
medicine-tracking/                 <- yeh poora folder aap ka project root hai
├── index.html                     UI (login, chat, admin)
├── manifest.json, service-worker.js, icons/icon.svg   (PWA)
├── css/   style.css  chat.css  animations.css  responsive.css
├── js/    firebase-config.js  auth.js  conversation.js  chat.js
│          voice.js  language.js  utils.js  admin.js  app.js
├── functions/
│   ├── index.js                   Gemini backend + admin + delete functions
│   ├── package.json
│   └── scripts/set-admin.js       admin custom-claim dene ki script
├── firestore.rules                Security rules
├── firestore.indexes.json         Required composite index
├── firebase.json, .firebaserc     Deploy config
└── README.md
```

Agar aap ki purani Medicine Tracking app maujood hai to is folder ko **alag jagah** rakhein (ya purane `index.html` ka backup lein) taake purani app na toote. Hosting `index.html` ko root par serve karta hai.

---

## 2. Free vs Paid (zaroor parhein)

| Service | Spark (free) | Blaze (pay-as-you-go) |
|---|---|---|
| Authentication (Google) | Haan | Haan |
| Cloud Firestore | Haan (daily free quota) | Haan |
| Hosting | Haan (free quota) | Haan |
| **Cloud Functions (2nd gen)** | **Nahi — deploy ke liye Blaze zaroori** | Haan (monthly free quota, uske baad charges) |
| Secret Manager (Gemini key) | **Blaze zaroori** | Thori si free quota |
| Gemini API | Google AI Studio key par free tier mil sakta hai (limits ke saath), paid tier alag | Usage ke hisaab se |

Baat seedhi hai: **AI chat ko Cloud Functions chahiye, is liye Blaze plan zaroori hai.** Blaze mein card/billing account lagta hai. Is project mein kuch bhi khud paid service on nahi hota — Blaze aap khud Firebase Console mein upgrade karte hain.

Kharcha control karne ke liye:
1. Google Cloud Console → **Billing → Budgets & alerts** mein chota budget (jaise $1–$5) + email alert lagayein.
2. Code mein limits pehle se hain: har user ke liye **8 messages/minute** aur **150 messages/din**, message max **2000 characters**, history context max 12 messages.
3. Admin panel se AI chat kisi bhi waqt **OFF** kar sakte hain.
4. Free quota current rates ke liye Firebase/Google ke pricing pages dekhein — rates badalte rehte hain.

Firestore reads kam rakhne ke liye: conversation list sirf 50 chats, messages 30-30 ki pages mein, listeners logout/close par band, offline cache on.

---

## 3. Phase-by-phase setup (har phase ke baad test)

### Phase 1 — Firebase Console setup
1. https://console.firebase.google.com → project **medicine-tracking-87531** kholein.
2. **Build → Authentication → Get started → Sign-in method → Google → Enable** (support email chunein → Save).
3. **Authentication → Settings → Authorized domains**: `localhost` aur `medicine-tracking-87531.web.app` / `.firebaseapp.com` pehle se hote hain. Apna custom domain ho to add karein.
4. **Build → Firestore Database → Create database** → *Production mode* → location chunein (baad mein badal nahi sakti).
5. **Project Settings → Usage and billing → Modify plan → Blaze** (sirf Cloud Functions ke liye; upar ka kharcha section parhein).

**Test:** Authentication aur Firestore dono console mein "enabled" dikhein.

### Phase 2 — Tools install
```bash
npm install -g firebase-tools
firebase login
cd medicine-tracking
firebase use medicine-tracking-87531
cd functions && npm install && cd ..
```
Node.js 22 chahiye (`node -v`).

### Phase 3 — Security rules + index deploy
```bash
firebase deploy --only firestore:rules,firestore:indexes
```
**Test:** Console → Firestore → Rules tab mein naye rules dikhein; Indexes tab mein `conversations (userId, updatedAt)` "Building" se "Enabled" ho jaye (1–2 minute).

### Phase 4 — Gemini secret + Functions deploy
1. https://aistudio.google.com/apikey se Gemini API key banayein.
2. Secret set karein (key terminal mein paste hogi, kisi file mein save nahi hoti):
```bash
firebase functions:secrets:set GEMINI_API_KEY
```
3. Deploy:
```bash
firebase deploy --only functions
```
Pehli baar Firebase aap se kuch Google APIs enable karne ko kahega (Cloud Build, Artifact Registry, Secret Manager) — `y` dein.

**Model badalna ho:** `functions/.env` file banayein: `GEMINI_MODEL=gemini-2.5-flash` (jo model aap ki key par available ho wo likhein; Google model names retire karta rehta hai) aur dobara `firebase deploy --only functions`.

**Test:** Console → Functions mein `sendMessage`, `deleteConversation`, `clearConversation`, `deleteAllConversations`, `adminGetOverview`, `adminUpdateConfig` dikhein.

### Phase 5 — Frontend deploy
Local test (optional):
```bash
npx serve . -l 5000        # phir http://localhost:5000 kholein
```
Live deploy:
```bash
firebase deploy --only hosting
```
Ya sab kuch ek saath: `firebase deploy`.

App yahan khulegi: `https://medicine-tracking-87531.web.app`

**Test:** Page khule → *Continue with Google* → login ho → sidebar mein apka naam/photo dikhe.

### Phase 6 — Admin banana
Aap ka email sirf **server-side** claim se admin banta hai (frontend mein koi PIN/flag nahi):
```bash
gcloud auth application-default login      # ek baar
cd functions
node scripts/set-admin.js your-email@gmail.com
```
Phir app mein **logout → login**. Sidebar mein *Admin panel* button aayega. (Koi aur user URL ya console se button dikha bhi le to backend `permission-denied` dega.)

---

## 4. Do Google accounts se testing (privacy check)

1. **Browser A** (normal window): Account A se login → "What is Panadol used for?" bhejein → jawab aaye.
2. **Browser B** (Incognito / dusra browser): Account B se login → sidebar **khali** hona chahiye (A ki chat nazar nahi aani chahiye).
3. B se ek alag chat bhejein. Wapas A mein dekhein: B ki chat nazar nahi aani chahiye.
4. Rules ka direct test: Console → Firestore → Rules → **Rules Playground** mein Account B ka UID daal kar A ke `conversations/<id>/messages/<id>` ko `get` karein → **Denied** aana chahiye.
5. Browser console (B ke tab mein) se A ki chat ID par `getDoc` try karein → `permission-denied`.

## 5. Logout ke baad history check

1. Account A se 2 chats banayein (har ek mein 2–3 messages).
2. **Log out** dabayein → login screen aaye.
3. Dobara Google se login karein → dono chats sidebar mein hon, kholne par saare messages wahi hon.
4. Refresh (F5) karein, phir doosre device/browser se login karein — history wahi hogi (sab Firestore mein hai).
5. Rename → refresh → naya naam barqarar. Delete → Firestore Console mein conversation aur uski `messages` subcollection dono ghayab.

---

## 6. Features checklist (jo is code mein implement hain)

- Google Sign-In (popup, blocked ho to redirect), profile `users/{uid}` mein save, returning users ka profile auto-load, logout.
- Chat: new chat, Enter se send (Shift+Enter = nayi line), user messages right / AI left, typing animation, auto-scroll + "scroll to latest" button, time stamps, copy, retry, empty state, skeleton loading, dark mode, mobile layout.
- Firestore real-time (`onSnapshot`), server timestamps, 30-30 messages ki pagination ("Load older messages"), offline cache + auto reconnect, listeners cleanup.
- **Duplicate se bachao:** har message ka `clientMessageId` hota hai; backend transaction se message "claim" karta hai, isliye double-click / retry par na dobara message banta hai na dobara AI jawab.
- Conversations: sidebar history, search, rename, delete one, delete all, clear conversation (sab confirmation ke saath; delete/clear Admin SDK se `recursiveDelete`).
- Backend: ID token verification (callable), ownership check, length limit (2000), per-user rate limit, Gemini timeout (45s) + 1 retry on 5xx, friendly error codes (quota / invalid key / timeout / unavailable / blocked), usage stats.
- Languages: Auto, English, Urdu, Roman Urdu, Hindi, Arabic, Punjabi. Urdu/Arabic selected hon to UI RTL ho jata hai; chat bubbles `dir="auto"` hain.
- Voice: mic button (explicit permission, sirf click par sunta hai, ek jumle ke baad ruk jata hai), text box mein aata hai taake bhejne se pehle edit kar saken, read-aloud / repeat / stop, "Read answers aloud" switch, unsupported browser par saaf message (Chrome/Edge best hain).
- Admin panel: users/conversations/messages counts, AI requests/success/errors/tokens, 7-din ka chart, recent API errors, AI ON/OFF, announcement, system instruction edit + reset.
- Security rules: browser se **koi bhi message (user ya assistant) likh nahi sakta**; sirf backend likhta hai.

## 7. Firestore data structure

```
users/{uid}                                  uid, displayName, email, photoURL, preferredLanguage, createdAt, lastLoginAt
conversations/{id}                           conversationId, userId, title, lastMessage, createdAt, updatedAt
conversations/{id}/messages/{clientId}       sender:user, text, timestamp, status, language, errorCode?
conversations/{id}/messages/{clientId}_ai    sender:assistant, text, timestamp, status, language, model
appConfig/public   (users read)              aiEnabled, announcement, announcementUpdatedAt
appConfig/private  (server only)             systemInstruction (custom override)
stats/*, rateLimits/*, apiErrors/*           server only
```

## 8. Common masail (troubleshooting)

| Masla | Wajah / hal |
|---|---|
| `auth/unauthorized-domain` | Authentication → Settings → Authorized domains mein domain add karein |
| `auth/operation-not-allowed` | Google provider enable nahi kiya (Phase 1) |
| Sidebar mein "index" ka error | `firebase deploy --only firestore:indexes` chalayein, 1–2 min intezar |
| "chat service is not deployed" | Functions deploy nahi hue (Phase 4) |
| "AI service is not configured correctly" | Gemini key galat/missing: `firebase functions:secrets:set GEMINI_API_KEY` phir `firebase deploy --only functions` |
| "AI model is not available" | `functions/.env` mein `GEMINI_MODEL` apne available model par set karein |
| "quota used up" | Gemini free limit khatam; thori der baad try karein ya billing/paid tier dekhein |
| Admin button nahi aaya | `set-admin.js` chalane ke baad **logout/login** zaroori hai |
| Mic kaam nahi karta | Chrome/Edge use karein, site ko microphone permission dein, HTTPS (ya localhost) zaroori hai |

## 9. Safety note

AI sirf **general health education** deta hai (system instruction mein safety rules hain: koi diagnosis/dose change nahi, emergency signs par fori madad ka mashwara). Yeh doctor ka badal nahi hai. Admin panel se system instruction badalte waqt safety rules barqarar rakhein.

---

POWERED BY MOAZAM | BHAMU
